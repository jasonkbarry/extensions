@echo off
title Nextiva Login Email Picker installer
rem Installs or updates Nextiva Login Email Picker. Double-click to run.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$x='nextiva-email-picker-blank'; irm https://jasonkbarry.github.io/extensions/install.txt | iex"
