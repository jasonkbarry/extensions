@echo off
title Row ID Copier installer
rem Installs or updates Row ID Copier. Double-click to run.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$x='row-id-copier'; irm https://jasonkbarry.github.io/extensions/install.txt | iex"
