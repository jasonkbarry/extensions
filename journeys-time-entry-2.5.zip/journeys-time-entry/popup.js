// Journeys Time Entry — popup (activity × day grid, synced with existing entries)
const $ = s => document.querySelector(s);
const send = msg => new Promise((resolve, reject) => {
  chrome.runtime.sendMessage(msg, r => {
    if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
    if (r && r.ok) resolve(r.result); else reject(new Error(r ? r.error : 'No response'));
  });
});
const store = {
  get: keys => chrome.storage.local.get(keys),
  set: obj => chrome.storage.local.set(obj)
};
const ymd = d => {
  const z = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
};
const md = s => { const [, m, d] = s.split('-'); return `${+m}/${+d}`; };
const prettyDate = s => new Date(s + 'T12:00:00').toLocaleDateString(undefined, { weekday: 'short', month: 'numeric', day: 'numeric' });
const fmtH = h => (Math.round(h * 100) / 100).toString();
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const LANES = [
  { code: 'new', label: 'New' }, { code: 'scope', label: 'Scope' }, { code: 'present', label: 'Present' },
  { code: 'test', label: 'Test' }, { code: 'acceptance', label: 'Acceptance' }, { code: 'on_hold', label: 'On Hold' }
];
const ADMIN_LABELS = {
  pto_holiday: 'FTO / Holiday', internal_meeting: 'Internal meeting', admin_email: 'Admin / email',
  training: 'Training', internal_project: 'Internal project', npi_management: 'NPI management'
};
const adminLabel = k => ADMIN_LABELS[k] || String(k).replace(/_/g, ' ').replace(/^./, c => c.toUpperCase());

let mode = 'project';
let boards = [];
let baseRows = [];        // project: all board cards [{id,title,lane,done}]; admin: pinned [{id,title}]
let rows = [];            // rows actually shown
let weekStart = null;     // Monday of shown week (Date, noon local)
let busy = false;
let confirmArmed = false; // deletes need a second click
let drafts = {};          // draftKey -> { cells: {rowId|date: '1.5'}, notes: {rowId: ''}, bill: {rowId: false}, errs: {rowId|date: msg} }
let weekCache = {};       // 'YYYY-MM-DD' (Monday) -> { at, entries: [...] }
let existing = {};        // rowId|date -> [entry, ...] for current mode/board/week

// ---------- dates ----------
function mondayOf(d) {
  const m = new Date(d); m.setHours(12, 0, 0, 0);
  m.setDate(m.getDate() - ((m.getDay() + 6) % 7));
  return m;
}
function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
const weekDates = () => DAY_NAMES.map((_, i) => ymd(addDays(weekStart, i)));

// ---------- drafts (typing survives closing the popup) ----------
const currentBoard = () => boards.find(b => b.workspaceId === $('#board').value);
const draftKey = () => `${mode}|${mode === 'project' ? $('#board').value : 'admin'}|${ymd(weekStart)}`;
function draft() {
  const k = draftKey();
  if (!drafts[k]) drafts[k] = { cells: {}, notes: {}, bill: {}, errs: {} };
  return drafts[k];
}
let saveTimer;
function saveDrafts() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    for (const [k, d] of Object.entries(drafts)) {
      const empty = !Object.keys(d.cells).length
        && !Object.values(d.notes).some(v => String(v).trim())
        && !Object.values(d.bill).some(v => v === false);
      if (empty) delete drafts[k];
    }
    store.set({ drafts });
  }, 250);
}

function setMsg(text, kind) {
  const el = $('#msg');
  el.textContent = text || '';
  el.className = 'msg' + (kind ? ' ' + kind : '');
}

// ---------- existing entries ----------
function buildExisting() {
  existing = {};
  const wk = weekCache[ymd(weekStart)];
  if (!wk) return;
  const ws = $('#board').value;
  for (const e of wk.entries) {
    let rowId = null;
    if (mode === 'project' && e.cardId && e.workspaceId === ws) rowId = e.cardId;
    if (mode === 'admin' && e.category) rowId = e.category;
    if (!rowId) continue;
    (existing[`${rowId}|${e.date}`] ||= []).push(e);
  }
}

function buildRows() {
  buildExisting();
  const withEntries = new Set(Object.keys(existing).map(k => k.split('|')[0]));
  if (mode === 'project') {
    // Cards chosen in settings, plus any other card on this board that has time this week
    const board = currentBoard();
    const picked = new Set((board && board.cards) || []);
    const laneOrder = c => LANES.findIndex(l => l.code === c.lane);
    const sorted = baseRows.slice().sort((a, b) => laneOrder(a) - laneOrder(b));
    rows = sorted.filter(c => picked.has(c.id))
      .concat(sorted.filter(c => !picked.has(c.id) && withEntries.has(c.id)).map(c => ({ ...c, extra: true })));
    for (const id of withEntries) {
      if (!rows.some(r => r.id === id)) rows.push({ id, title: 'Card not on board', extra: true });
    }
  } else {
    rows = baseRows.slice();
    for (const id of withEntries) {
      if (!rows.some(r => r.id === id)) rows.push({ id, title: adminLabel(id), extra: true });
    }
  }
}

async function loadEntries(force) {
  const wkKey = ymd(weekStart);
  const cached = weekCache[wkKey];
  if (cached && !force && Date.now() - cached.at < 60 * 1000) return;
  try {
    const entries = await send({ type: 'weekEntries', from: wkKey, to: ymd(addDays(weekStart, 6)) });
    weekCache[wkKey] = { at: Date.now(), entries };
    store.set({ weekCache: pruneCache(weekCache) });
    if (ymd(weekStart) === wkKey) refreshGrid();
  } catch (e) {
    setMsg('Couldn’t load existing entries: ' + e.message, 'err');
  }
}
function pruneCache(c) {
  const keys = Object.keys(c).sort().slice(-4);
  return Object.fromEntries(keys.map(k => [k, c[k]]));
}

// ---------- cell state ----------
function cellInfo(rowId, date) {
  const key = `${rowId}|${date}`;
  const ex = existing[key] || [];
  const server = ex.reduce((s, e) => s + e.hours, 0);
  const d = draft();
  const hasDraft = Object.prototype.hasOwnProperty.call(d.cells, key);
  const shown = ex.length > 1 ? fmtH(server) : (hasDraft ? d.cells[key] : (ex.length ? fmtH(server) : ''));
  return { key, ex, server, hasDraft, shown };
}

function computeOps() {
  const today = ymd(new Date());
  const d = draft();
  const ops = [];
  const problems = [];
  for (const r of rows) {
    for (const date of weekDates()) {
      const c = cellInfo(r.id, date);
      if (!c.hasDraft || c.ex.length > 1) continue;
      const raw = String(d.cells[c.key]).trim();
      const h = raw === '' ? 0 : parseFloat(raw);
      if (!(h >= 0) || h > 24) { problems.push(`${r.title} · ${prettyDate(date)}`); continue; }
      if (c.ex.length === 0) {
        if (h === 0) continue;
        if (date > today) { problems.push(`${r.title} · ${prettyDate(date)} (future)`); continue; }
        ops.push({ op: 'create', row: r, date, hours: h, key: c.key });
      } else {
        const e = c.ex[0];
        if (h === 0) ops.push({ op: 'delete', row: r, date, hours: e.hours, key: c.key, entry: e });
        else if (Math.abs(h - e.hours) > 1e-9) ops.push({ op: 'update', row: r, date, hours: h, key: c.key, entry: e });
      }
    }
  }
  return { ops, problems };
}

// ---------- grid ----------
function renderGrid() {
  const dates = weekDates();
  const today = ymd(new Date());
  const d = draft();

  $('#wkLabel').textContent = `${md(dates[0])} – ${md(dates[6])}`;
  const thisMon = ymd(mondayOf(new Date()));
  $('#nextWk').disabled = dates[0] >= thisMon;
  $('#thisWk').hidden = dates[0] === thisMon;

  const table = document.querySelector('.grid');
  table.querySelector('colgroup')?.remove();
  table.insertAdjacentHTML('afterbegin', `<colgroup><col class="c-act">${dates.map(() => '<col>').join('')}<col class="c-tot"></colgroup>`);

  $('#gHead').innerHTML = `<tr><th class="act">${mode === 'project' ? 'Activity' : 'Category'}</th>${dates.map((dt, i) =>
    `<th class="${dt === today ? 'today' : ''} ${i >= 5 ? 'weekend' : ''}">${DAY_NAMES[i]}<span class="dd">${md(dt)}</span></th>`).join('')}<th>Tot</th></tr>`;

  if (!rows.length) {
    $('#gBody').innerHTML = `<tr class="empty-row"><td colspan="9">${mode === 'project' ? 'No activities selected for this customer — click ⚙ and tick the cards you log time to.' : 'No pinned categories.'}</td></tr>`;
  } else {
    $('#gBody').innerHTML = rows.map(r => {
      const billable = mode === 'project' ? d.bill[r.id] !== false : false;
      const pill = mode === 'project'
        ? `<button class="bill ${billable ? '' : 'no'}" data-bill="${esc(r.id)}" title="Billing for NEW entries in this row — click to switch">${billable ? 'BILLABLE' : 'NON-BILL'}</button>`
        : '';
      const rowErrs = dates.map(dt => d.errs[`${r.id}|${dt}`]).filter(Boolean);
      return `<tr data-row="${esc(r.id)}" class="${rowErrs.length ? 'row-err' : ''} ${r.extra ? 'extra' : ''}">
        <td class="act">
          <div class="act-name"><span title="${esc(r.title)}">${esc(r.title)}${r.extra ? ' <em>(not selected)</em>' : ''}</span>${pill}</div>
          <input class="act-note" data-note="${esc(r.id)}" placeholder="Comment for new entries" value="${esc(d.notes[r.id] ?? '')}">
          ${rowErrs.length ? `<div class="row-error">⚠ ${esc(rowErrs[0])}</div>` : ''}
        </td>
        ${dates.map(dt => {
          const c = cellInfo(r.id, dt);
          const future = dt > today;
          const multi = c.ex.length > 1;
          let cls = '';
          if (d.errs[c.key]) cls = 'err';
          else if (multi) cls = 'saved multi';
          else if (c.hasDraft && c.ex.length && String(d.cells[c.key]).trim() === '') cls = 'del';
          else if (c.hasDraft && c.ex.length && parseFloat(d.cells[c.key]) !== c.server) cls = 'has';
          else if (c.hasDraft && !c.ex.length && String(d.cells[c.key]).trim()) cls = 'has';
          else if (c.ex.length) cls = 'saved';
          const tip = c.ex.length
            ? c.ex.map(e => `${fmtH(e.hours)} h · ${e.billable ? 'Billable' : 'Non-billable'}${e.notes ? ' · ' + e.notes : ''}`).join('\n')
              + (multi ? '\n(Multiple entries — edit these in Journeys)' : '\n(Clear the cell to delete)')
            : (future ? 'Future date' : '');
          const disabled = multi || (future && !c.ex.length);
          return `<td class="cell ${dt === today ? 'today' : ''}"><div class="cwrap">
            <input type="number" min="0" max="24" step="0.25" inputmode="decimal"
              data-cell="${esc(c.key)}" class="${cls}" value="${esc(c.shown)}" placeholder="${c.ex.length === 1 ? 'del' : '–'}"
              ${disabled ? 'disabled' : ''} title="${esc(d.errs[c.key] || tip)}">${multi ? `<span class="badge">${c.ex.length}</span>` : ''}</div></td>`;
        }).join('')}
        <td class="tot" data-rtot="${esc(r.id)}"></td>
      </tr>`;
    }).join('');
  }
  $('#gFoot').innerHTML = `<tr><td class="act">Day total</td>${dates.map(dt => `<td data-dtot="${dt}"></td>`).join('')}<td class="grand" id="grand"></td></tr>`;
  updateTotals();
}

// Re-render but keep focus/caret if the user is typing
function refreshGrid() {
  const a = document.activeElement;
  const focusKey = a && (a.dataset.cell ? ['cell', a.dataset.cell] : a.dataset.note ? ['note', a.dataset.note] : null);
  buildRows();
  renderGrid();
  renderSummary();
  if (focusKey) {
    const el = document.querySelector(`[data-${focusKey[0]}="${CSS.escape(focusKey[1])}"]`);
    if (el && !el.disabled) el.focus();
  }
}

function updateTotals() {
  const dates = weekDates();
  const val = (rowId, dt) => { const h = parseFloat(cellInfo(rowId, dt).shown); return h > 0 ? h : 0; };
  let grand = 0;
  for (const r of rows) {
    const t = dates.reduce((s, dt) => s + val(r.id, dt), 0);
    const el = document.querySelector(`[data-rtot="${CSS.escape(r.id)}"]`);
    if (el) el.textContent = t ? fmtH(t) : '';
    grand += t;
  }
  for (const dt of dates) {
    const t = rows.reduce((s, r) => s + val(r.id, dt), 0);
    const el = document.querySelector(`[data-dtot="${dt}"]`);
    if (el) el.textContent = t ? fmtH(t) : '';
  }
  const g = $('#grand'); if (g) g.textContent = grand ? fmtH(grand) : '';

  const { ops } = computeOps();
  const n = t => ops.filter(o => o.op === t).length;
  const parts = [];
  if (n('create')) parts.push(`${n('create')} new`);
  if (n('update')) parts.push(`${n('update')} change${n('update') > 1 ? 's' : ''}`);
  if (n('delete')) parts.push(`${n('delete')} delete${n('delete') > 1 ? 's' : ''}`);
  const btn = $('#submitBtn');
  btn.disabled = busy || ops.length === 0;
  btn.classList.toggle('danger', confirmArmed);
  btn.textContent = busy ? 'Submitting…'
    : confirmArmed ? `Confirm: ${parts.join(' · ')}`
    : ops.length ? `Submit: ${parts.join(' · ')}` : 'No changes';
}

function disarm() {
  if (!confirmArmed) return;
  confirmArmed = false;
  setMsg('');
}

// ---------- loading rows ----------
async function loadRows(force) {
  if (mode === 'project') {
    const ws = $('#board').value;
    if (!ws) { baseRows = []; refreshGrid(); return; }
    const { actCache = {} } = await store.get('actCache');
    if (actCache[ws]) { baseRows = actCache[ws].list; refreshGrid(); }
    if (actCache[ws] && actCache[ws].list.some(c => c.lane !== undefined) && !force && Date.now() - actCache[ws].at < 10 * 60 * 1000) return;
    try {
      const list = await send({ type: 'activities', workspaceId: ws });
      if ($('#board').value !== ws || mode !== 'project') return;
      actCache[ws] = { at: Date.now(), list };
      await store.set({ actCache });
      baseRows = list;
    } catch (e) {
      return setMsg(e.message, 'err');
    }
  } else {
    const { pinCache } = await store.get('pinCache');
    if (pinCache) { baseRows = pinCache.list.map(p => ({ id: p.key, title: p.label })); refreshGrid(); }
    if (pinCache && !force && Date.now() - pinCache.at < 60 * 60 * 1000) return;
    try {
      const pins = await send({ type: 'pins' });
      if (mode !== 'admin') return;
      await store.set({ pinCache: { at: Date.now(), list: pins } });
      baseRows = pins.map(p => ({ id: p.key, title: p.label }));
    } catch (e) {
      return setMsg(e.message, 'err');
    }
  }
  refreshGrid();
}

// Header summary for the week shown in the grid (from what is saved in Journeys)
const CAPACITY_PER_WEEK = 32;                 // billable hours
const CAPACITY_PER_DAY = CAPACITY_PER_WEEK / 5; // 6.4 per business day
const FTO_CATEGORY = 'pto_holiday';

function weekSummary() {
  const wk = weekCache[ymd(weekStart)];
  if (!wk) return null;
  const today = ymd(new Date());
  const dates = weekDates();
  const businessDaysSoFar = dates.slice(0, 5).filter(d => d <= today).length;
  const sum = list => list.reduce((s, e) => s + (Number(e.hours) || 0), 0);
  const all = wk.entries;
  const fto = sum(all.filter(e => e.category === FTO_CATEGORY && e.date <= today));
  const worked = all.filter(e => e.category !== FTO_CATEGORY);
  const total = sum(worked);
  const billable = sum(worked.filter(e => e.billable));
  const expected = Math.max(0, businessDaysSoFar * CAPACITY_PER_DAY - fto);
  return {
    total, billable, fto, expected, businessDaysSoFar,
    billablePct: total ? billable / total : null,
    capacityPct: expected ? billable / expected : null
  };
}

function renderSummary() {
  const el = $('#week');
  const s = weekSummary();
  if (!s) { el.textContent = 'Loading week…'; return; }
  const pct = v => v === null ? '–' : `${Math.round(v * 100)}%`;
  const capCls = s.capacityPct === null ? '' : s.capacityPct >= 1 ? 'good' : s.capacityPct >= 0.8 ? 'ok' : 'low';
  el.innerHTML = `<span class="kpi"><b>${fmtH(s.total)} h</b> logged</span>
    <span class="kpi"><b>${pct(s.billablePct)}</b> billable <i>(${fmtH(s.billable)} h)</i></span>
    <span class="kpi cap ${capCls}"><b>${pct(s.capacityPct)}</b> capacity <i>(${fmtH(s.billable)} / ${fmtH(s.expected)} h)</i></span>`;
  el.title = `Billable % = billable ÷ hours logged (FTO/holiday not counted).\n`
    + `Capacity = ${CAPACITY_PER_DAY} h × ${s.businessDaysSoFar} business day${s.businessDaysSoFar === 1 ? '' : 's'} through today`
    + (s.fto ? ` − ${fmtH(s.fto)} h FTO/holiday` : '') + ` = ${fmtH(s.expected)} h (32 h per full week).`;
}

function loadWeek() { renderSummary(); }

function showWeek(start) {
  weekStart = start;
  disarm();
  refreshGrid();
  loadEntries(false);
}

function setMode(m) {
  mode = m;
  document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('active', b.dataset.mode === m));
  $('#board').hidden = m !== 'project';
  $('#adminHint').hidden = m !== 'admin';
  $('#syncBtn').hidden = m !== 'project';
  $('#refresh').title = m === 'project' ? 'Reload activities and entries' : 'Reload categories and entries';
  store.set({ lastMode: m });
  setMsg('');
  confirmArmed = false;
  baseRows = [];
  refreshGrid();
  loadRows(false);
  loadEntries(false);
}

// ---------- Sync (Journeys ↔ Burn Down) ----------
let sync = null;                 // { board, from, to, days: [...], cards: [...] }
const syncTyped = {};            // Burn Down row id -> { cardId, note } (kept across reloads)
let syncArmed = null;            // key of the Delete button waiting for a confirm click
let syncBusy = false;

function showView(name) {
  $('#entryView').hidden = name !== 'entry';
  $('#settingsView').hidden = name !== 'settings';
  $('#syncView').hidden = name !== 'sync';
}

async function openSync() {
  const board = currentBoard();
  if (!board) return setMsg('Pick a customer first.', 'err');
  if (!sheetComplete(board.sheet)) return setMsg(`Fill in the Burn Down info for ${board.name} in ⚙ settings first.`, 'err');
  showView('sync');
  await loadSync();
}

function syncStatus(text, kind) {
  const sm = $('#syncMsg'); sm.className = 'msg' + (kind ? ' ' + kind : ''); sm.textContent = text || '';
}

async function loadSync(keepMsg) {
  const board = currentBoard();
  const from = ymd(weekStart), to = ymd(addDays(weekStart, 6));
  $('#syncTitle').textContent = `Sync · ${board.name}`;
  $('#syncWk').textContent = `${md(from)} – ${md(to)}`;
  const thisMon = ymd(mondayOf(new Date()));
  $('#syncNext').disabled = from >= thisMon;
  $('#syncThis').hidden = from === thisMon;
  $('#syncDays').innerHTML = '';
  if (!keepMsg) syncStatus('Comparing Journeys with the Burn Down sheet…');
  try {
    const [entries, sheetRowsAll] = await Promise.all([
      send({ type: 'weekEntries', from, to }),
      send({ type: 'sheetList', customer: board.sheet.customer, from, to })
    ]);
    weekCache[from] = { at: Date.now(), entries };
    renderSummary();
    const sheetRows = sheetRowsAll.filter(r => r.hours > 0);   // rows set to 0 after a delete are ignored
    const { actCache = {} } = await store.get('actCache');
    const allCards = (actCache[board.workspaceId] && actCache[board.workspaceId].list) || baseRows;
    const title = id => (allCards.find(c => c.id === id) || {}).title || 'Card not on board';
    const journeys = entries.filter(e => e.workspaceId === board.workspaceId && e.billable);

    const days = weekDates().map(date => {
      const js = journeys.filter(e => e.date === date).map(e => ({ ...e, cardTitle: title(e.cardId) }));
      const ss = sheetRows.filter(r => r.date === date);
      const used = new Set();
      const pairs = [], jOnly = [];
      for (const j of js) {
        const k = ss.findIndex((r, i) => !used.has(i) && Math.abs(r.hours - j.hours) < 1e-6);
        if (k >= 0) { used.add(k); pairs.push({ j, s: ss[k] }); } else jOnly.push(j);
      }
      const sOnly = ss.filter((_, i) => !used.has(i));
      const sum = l => l.reduce((t, x) => t + x.hours, 0);
      return { date, pairs, jOnly, sOnly, jTotal: sum(js), sTotal: sum(ss) };
    });
    const picked = new Set(board.cards || []);
    const cards = allCards.filter(c => picked.has(c.id)).concat(allCards.filter(c => !picked.has(c.id)));
    sync = { board, from, to, days, cards };
    const jt = days.reduce((t, d) => t + d.jTotal, 0), st = days.reduce((t, d) => t + d.sTotal, 0);
    const open = days.reduce((t, d) => t + d.jOnly.length + d.sOnly.length, 0);
    if (!keepMsg) syncStatus(`Journeys ${fmtH(jt)} h billable · Burn Down ${fmtH(st)} h · ${open ? `${open} line${open === 1 ? '' : 's'} to resolve` : 'everything matches'}`, open ? '' : 'ok');
    renderSync();
  } catch (e) {
    syncStatus(e.message, 'err');
  }
}

function hrsInput(key, hours) {
  return `<span class="hrs"><input type="number" min="0.25" max="24" step="0.25" data-hrs="${key}" data-orig="${hours}" value="${fmtH(hours)}" aria-label="Hours">h</span>
    <button class="btn small secondary" data-save="${key}" hidden>Save</button>`;
}

function delBtn(key, label = 'Delete') {
  const armed = syncArmed === key;
  return `<button class="btn small ${armed ? 'danger' : 'ghost'}" data-del="${key}">${armed ? 'Confirm' : label}</button>`;
}

function renderSync() {
  const today = ymd(new Date());
  const { days, cards } = sync;
  const opts = cards.map(c => `<option value="${esc(c.id)}">${esc(c.title)}</option>`).join('');
  const shown = days.filter(d => d.pairs.length || d.jOnly.length || d.sOnly.length);
  $('#syncDays').innerHTML = shown.length ? shown.map((d, di) => {
    const di0 = days.indexOf(d);
    const diff = Math.abs(d.jTotal - d.sTotal) > 1e-6;
    return `<section class="day">
      <div class="day-h"><span>${prettyDate(d.date)}</span>
        <span class="tots ${diff ? 'diff' : ''}"><i class="src j">J</i> ${fmtH(d.jTotal)} h &nbsp; <i class="src b">B</i> ${fmtH(d.sTotal)} h</span></div>
      ${d.pairs.map((p, i) => `<div class="item pair">
          <div class="top"><i class="src j">J</i><i class="src b">B</i><span class="what">${esc(p.j.cardTitle)}</span>${hrsInput(`p:${di0}:${i}`, p.j.hours)}${delBtn(`p:${di0}:${i}`)}</div>
          <div class="sub">${p.j.notes ? esc(p.j.notes) + ' · ' : ''}${esc(p.s.id)}</div></div>`).join('')}
      ${d.jOnly.map((j, i) => `<div class="item j-only">
          <div class="top"><i class="src j">J</i><span class="what">${esc(j.cardTitle)}</span>${hrsInput(`j:${di0}:${i}`, j.hours)}
            <button class="btn small primary" data-addb="${di0}:${i}" title="Add this to the Burn Down sheet">+BurnDown</button>${delBtn(`j:${di0}:${i}`)}</div>
          <div class="sub">${j.notes ? esc(j.notes) + ' · ' : ''}not in Burn Down</div></div>`).join('')}
      ${d.sOnly.map((s, i) => {
        const t = syncTyped[s.id] || {};
        const future = d.date > today;
        return `<div class="item s-only">
          <div class="top"><i class="src b">B</i><span class="what">${esc(s.id)}</span>${hrsInput(`s:${di0}:${i}`, s.hours)}
            ${future ? '' : `<button class="btn small primary" data-addj="${di0}:${i}" title="Log this in Journeys">+Journey</button>`}${delBtn(`s:${di0}:${i}`)}</div>
          <div class="sub">row ${s.row} · not in Journeys${future ? ' · future date, so fix it in the sheet' : ''}</div>
          ${future ? '' : `<div class="row2">
            <select data-scard="${esc(s.id)}" aria-label="Activity">${cards.length ? opts : '<option value="">No cards loaded</option>'}</select>
            <input data-snote="${esc(s.id)}" placeholder="Comment for Journeys" value="${esc(t.note || '')}"></div>`}
        </div>`;
      }).join('')}
    </section>`;
  }).join('') : '<div class="sync-empty">No billable time in Journeys or Burn Down for this customer this week.</div>';
  days.forEach(d => d.sOnly.forEach(s => {
    const t = syncTyped[s.id]; const el = document.querySelector(`[data-scard="${CSS.escape(s.id)}"]`);
    if (el && t && t.cardId) el.value = t.cardId;
  }));
  document.querySelectorAll('#syncDays button').forEach(b => { b.disabled = syncBusy; });
}

async function syncAction(fn) {
  if (syncBusy) return;
  syncBusy = true; syncArmed = null; renderSync();
  let msg, kind = 'ok';
  try { msg = await fn(); } catch (e) { msg = e.message; kind = 'err'; }
  syncBusy = false;
  syncStatus(msg, kind);
  await loadSync(true);
}

function addToBurnDown(di, i) {
  const j = sync.days[di].jOnly[i];
  const sh = sync.board.sheet;
  return syncAction(async () => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(j.date || '')) throw new Error('This entry has no date, so it was not added.');
    const r = await send({ type: 'sheetAddRows', rows: [{ customer: sh.customer, account: sh.account, date: j.date, hours: j.hours,
      csp: sh.csp, allotted: sh.allotted, bucket: sh.bucket, ref: j.id }] });
    const w = (r.written || [])[0];
    if (!w || !w.row) throw new Error('The Burn Down sheet did not add the row' + (w && w.error ? ': ' + w.error : '.'));
    return `Added to Burn Down: ${w.id || 'row ' + w.row} (${prettyDate(j.date)}, ${fmtH(j.hours)} h).`;
  });
}

function addToJourneys(di, i) {
  const s = sync.days[di].sOnly[i];
  const t = syncTyped[s.id] || {};
  const sel = document.querySelector(`[data-scard="${CSS.escape(s.id)}"]`);
  const cardId = t.cardId || (sel && sel.value);
  const card = sync.cards.find(c => c.id === cardId);
  if (!card) return syncStatus('Pick an activity for that line first.', 'err');
  return syncAction(async () => {
    const item = { id: crypto.randomUUID(), op: 'create', kind: 'project', cardId: card.id, cardTitle: card.title, boardName: sync.board.name,
      date: s.date, hours: s.hours, billable: true, notes: (t.note || '').trim() };   // no sheetRow: the row already exists
    const resp = await send({ type: 'submitItems', items: [item] });
    const res = (resp.results || resp)[item.id];
    if (!res || !res.ok) throw new Error((res && res.error) || 'Journeys did not save the entry.');
    delete syncTyped[s.id];
    return `Added to Journeys: ${card.title}, ${prettyDate(s.date)}, ${fmtH(s.hours)} h.`;
  });
}

function syncSaveHours(key) {
  const input = document.querySelector(`[data-hrs="${key}"]`);
  const h = parseFloat(input && input.value);
  if (!(h > 0) || h > 24) return syncStatus('Hours must be between 0.25 and 24. To remove a line, use Delete.', 'err');
  const [kind, di, i] = key.split(':'); const d = sync.days[Number(di)];
  const sh = sync.board.sheet;
  const patchJourneys = async j => {
    const item = { id: crypto.randomUUID(), op: 'update', kind: 'project', entryId: j.id, cardId: j.cardId, cardTitle: j.cardTitle,
      boardName: sync.board.name, date: j.date, hours: h, oldHours: j.hours, billable: true, notes: j.notes };
    const resp = await send({ type: 'submitItems', items: [item] });
    const res = (resp.results || resp)[item.id];
    if (!res || !res.ok) throw new Error((res && res.error) || 'Journeys did not save the change.');
  };
  const setSheet = async s => {
    const u = await send({ type: 'sheetSetHours', rows: [{ row: s.row, customer: sh.customer, date: s.date, newHours: h, ref: s.id }] });
    if (!u[0] || !u[0].row) throw new Error(`Burn Down ${s.id} was not changed${u[0] && u[0].error ? ': ' + u[0].error : ''}.`);
  };
  if (kind === 'j') {
    const j = d.jOnly[Number(i)];
    return syncAction(async () => { await patchJourneys(j); return `Journeys: ${j.cardTitle} ${prettyDate(j.date)} changed ${fmtH(j.hours)} → ${fmtH(h)} h.`; });
  }
  if (kind === 's') {
    const s = d.sOnly[Number(i)];
    return syncAction(async () => { await setSheet(s); return `Burn Down: ${s.id} changed ${fmtH(s.hours)} → ${fmtH(h)} h.`; });
  }
  const p = d.pairs[Number(i)];
  return syncAction(async () => {
    await patchJourneys(p.j);
    try { await setSheet(p.s); }
    catch (e) { throw new Error(`Journeys changed to ${fmtH(h)} h, but ${e.message} Fix the Burn Down row by hand or sync again.`); }
    return `${p.j.cardTitle} ${prettyDate(p.j.date)} changed ${fmtH(p.j.hours)} → ${fmtH(h)} h in Journeys and Burn Down (${p.s.id}).`;
  });
}

function syncDelete(key) {
  if (syncArmed !== key) { syncArmed = key; renderSync(); return; }   // first click arms, second confirms
  const [kind, di, i] = key.split(':'); const d = sync.days[Number(di)];
  const sh = sync.board.sheet;
  const delJourneys = async (j, zero) => {
    const item = { id: crypto.randomUUID(), op: 'delete', kind: 'project', entryId: j.id, cardId: j.cardId, cardTitle: j.cardTitle,
      boardName: sync.board.name, date: j.date, hours: j.hours, oldHours: j.hours, billable: true, notes: j.notes,
      ...(zero ? { sheetZero: zero } : {}) };
    const resp = await send({ type: 'submitItems', items: [item] });
    const res = (resp.results || resp)[item.id];
    if (!res || !res.ok) throw new Error((res && res.error) || 'Journeys did not delete the entry.');
    return resp.zero;
  };
  if (kind === 's') {
    const s = d.sOnly[Number(i)];
    return syncAction(async () => {
      const z = await send({ type: 'sheetZeroRows', rows: [{ row: s.row, customer: sh.customer, date: s.date, hours: s.hours, ref: s.id }] });
      if (!z[0] || !z[0].row) throw new Error('Could not find that Burn Down row to clear.');
      return `${s.id} set to 0 h in Burn Down (row kept).`;
    });
  }
  if (kind === 'j') {
    const j = d.jOnly[Number(i)];
    return syncAction(async () => { await delJourneys(j, null); return `Deleted from Journeys: ${j.cardTitle}, ${prettyDate(j.date)}, ${fmtH(j.hours)} h.`; });
  }
  const p = d.pairs[Number(i)];
  return syncAction(async () => {
    const zero = await delJourneys(p.j, { row: p.s.row, customer: sh.customer, date: p.s.date, hours: p.s.hours });
    const ok = zero && zero.ok && zero.zeroed && zero.zeroed[0] && zero.zeroed[0].row;
    return `Deleted from Journeys: ${p.j.cardTitle}, ${prettyDate(p.j.date)}, ${fmtH(p.j.hours)} h. `
      + (ok ? `${p.s.id} set to 0 h in Burn Down.` : `Burn Down row ${p.s.id} was NOT changed${zero && zero.error ? ': ' + zero.error : ''}.`);
  });
}

// ---------- submit ----------
async function submit() {
  if (busy) return;
  const { ops, problems } = computeOps();
  if (problems.length) return setMsg(`Fix these cells (0.25–24 h; new entries can’t be in the future): ${problems.join(', ')}`, 'err');
  if (!ops.length) return;

  const dels = ops.filter(o => o.op === 'delete');
  if (dels.length && !confirmArmed) {
    confirmArmed = true;
    setMsg(`This will permanently delete ${dels.length} entr${dels.length === 1 ? 'y' : 'ies'} in Journeys: `
      + dels.map(o => `${o.row.title} ${prettyDate(o.date)} (${fmtH(o.hours)} h)`).join('; ')
      + '. Click the button again to confirm.', 'err');
    updateTotals();
    return;
  }
  confirmArmed = false;

  const d = draft();
  const board = currentBoard();
  const sheetInfo = board && board.sheet;
  const billableCreates = mode === 'project' ? ops.filter(o => o.op === 'create' && d.bill[o.row.id] !== false) : [];
  if (billableCreates.length && !sheetComplete(sheetInfo)) {
    return setMsg(`Fill in the Burn Down info for ${board ? board.name : 'this customer'} in ⚙ settings (customer, account #, CSP level) before submitting billable time.`, 'err');
  }
  const items = ops.map(o => {
    const base = { id: crypto.randomUUID(), op: o.op, kind: mode, date: o.date, hours: o.hours, cellKey: o.key };
    const what = mode === 'project'
      ? { cardId: o.row.id, cardTitle: o.row.title, boardName: board ? board.name : '' }
      : { category: o.row.id, categoryLabel: o.row.title };
    if (o.op === 'create') {
      const billable = mode === 'project' && d.bill[o.row.id] !== false;
      const item = { ...base, ...what, notes: (d.notes[o.row.id] || '').trim(), ...(mode === 'project' ? { billable } : {}) };
      if (billable) item.sheetRow = { customer: sheetInfo.customer, account: sheetInfo.account, date: o.date, hours: o.hours,
        csp: sheetInfo.csp, allotted: sheetInfo.allotted, bucket: sheetInfo.bucket };
      return item;
    }
    const it = { ...base, ...what, entryId: o.entry.id, notes: o.entry.notes, billable: o.entry.billable, oldHours: o.entry.hours };
    if (o.op === 'delete' && mode === 'project' && o.entry.billable && sheetComplete(sheetInfo)) {
      it.sheetZero = { customer: sheetInfo.customer, date: o.date, hours: o.entry.hours };
    }
    return it;
  });

  busy = true;
  updateTotals();
  setMsg(`Submitting ${items.length} change${items.length === 1 ? '' : 's'}…`);
  const key = draftKey();
  try {
    const resp = await send({ type: 'submitItems', items });
    const results = resp.results || resp;
    const dd = drafts[key] || d;
    let ok = 0, bad = 0;
    for (const it of items) {
      const res = results[it.id];
      if (res && res.ok) { ok++; delete dd.cells[it.cellKey]; delete dd.errs[it.cellKey]; }
      else { bad++; dd.errs[it.cellKey] = (res && res.error) || 'Not submitted'; }
    }
    for (const r of rows) {
      const left = Object.keys(dd.cells).some(k => k.startsWith(r.id + '|'));
      if (!left) { delete dd.notes[r.id]; delete dd.bill[r.id]; }
    }
    saveDrafts();
    let text = bad ? `${ok} saved, ${bad} failed — failed cells are red and kept so you can retry.` : `✓ ${ok} change${ok === 1 ? '' : 's'} saved to Journeys.`;
    let kind = bad ? 'err' : 'ok';
    if (resp.sheet) {
      if (resp.sheet.ok) {
        const ok = resp.sheet.written.filter(w => w.row);
        const ids = ok.map(w => w.id || ('row ' + w.row));
        text += ` Burn Down: ${ids.length} row${ids.length === 1 ? '' : 's'} added (${ids.join(', ')}).`;
        const skipped = resp.sheet.written.length - ok.length;
        if (skipped) { text += ` ${skipped} skipped because ${skipped === 1 ? 'it had' : 'they had'} no date.`; kind = 'err'; }
      } else {
        text += ` Burn Down sheet NOT updated: ${resp.sheet.error} The rows are saved and will be retried.`;
        kind = 'err';
      }
    }
    if (resp.zero) {
      if (resp.zero.ok) {
        const hit = resp.zero.zeroed.filter(z => z.row);
        const miss = resp.zero.zeroed.length - hit.length;
        if (hit.length) text += ` Burn Down: set ${hit.length} row${hit.length === 1 ? '' : 's'} to 0 h (${hit.map(z => z.id || 'row ' + z.row).join(', ')}).`;
        if (miss) text += ` ${miss} deleted entr${miss === 1 ? 'y had' : 'ies had'} no matching Burn Down row.`;
      } else {
        text += ` Burn Down hours NOT set to 0: ${resp.zero.error} Saved for retry.`;
        kind = 'err';
      }
    }
    const billableEdits = items.filter(it => it.op === 'update' && it.kind === 'project' && it.billable && results[it.id] && results[it.id].ok);
    if (billableEdits.length) text += ` Note: ${billableEdits.length} billable hour change${billableEdits.length === 1 ? '' : 's'} not applied to the Burn Down sheet — update those rows by hand.`;
    setMsg(text, kind);
  } catch (e) {
    setMsg(e.message, 'err');
  } finally {
    busy = false;
    await loadEntries(true);   // pull fresh state so the grid shows what Journeys now has
    refreshGrid();
    renderLog();
    loadWeek();
    renderSheetBar();
  }
}

// ---------- Burn Down helpers ----------
const CSP_LEVELS = ['Standard - TAM', 'Advanced - TAM', 'Signature - TAM'];
const sheetComplete = sh => !!(sh && String(sh.customer || '').trim() && String(sh.account || '').trim() && String(sh.csp || '').trim());

async function renderSheetBar() {
  const { sheetPending = [] } = await store.get('sheetPending');
  $('#sheetBar').hidden = !sheetPending.length;
  $('#sheetBarText').textContent = `${sheetPending.length} Burn Down update${sheetPending.length === 1 ? '' : 's'} waiting to be written to the sheet.`;
}
async function retrySheet() {
  $('#sheetBarText').textContent = 'Writing to Burn Down sheet…';
  try {
    const r = await send({ type: 'sheetRetry' });
    const z = (r.zeroed || []).filter(x => x.row).length;
    setMsg(`Burn Down: ${r.written.length} row${r.written.length === 1 ? '' : 's'} added${z ? `, ${z} set to 0 h` : ''}.`, 'ok');
  } catch (e) {
    setMsg(e.message, 'err');
  }
  renderSheetBar();
}

async function renderLog() {
  const { log = [] } = await store.get('log');
  $('#logWrap').hidden = !log.length;
  const verb = q => q.op === 'delete' ? 'Deleted' : q.op === 'update' ? 'Changed' : 'Added';
  $('#log').innerHTML = log.slice(0, 15).map(q => {
    const what = q.kind === 'project' ? `${esc(q.boardName)} · ${esc(q.cardTitle)}${q.op === 'create' && !q.billable ? ' (non-billable)' : ''}` : `Admin · ${esc(q.categoryLabel)}`;
    const hrs = q.op === 'update' ? `${fmtH(q.oldHours)} → ${fmtH(q.hours)} h` : `${fmtH(q.hours)} h`;
    return `<li><div class="body"><div class="top">${verb(q)}: ${what}</div>
      <div class="sub">${prettyDate(q.date)} · ${hrs}${q.notes ? ' · ' + esc(q.notes) : ''}</div></div></li>`;
  }).join('');
}

// ---------- settings ----------
async function toggleActs(i, btn) {
  const box = document.querySelector(`[data-actlist="${i}"]`);
  const b = boards[i];
  if (!box.hidden) { box.hidden = true; btn.textContent = `Activities: ${(b.cards || []).length} selected ▸`; return; }
  box.hidden = false;
  btn.textContent = `Activities: ${(b.cards || []).length} selected ▾`;
  box.innerHTML = '<div class="hint">Loading cards…</div>';
  try {
    const list = await send({ type: 'activities', workspaceId: b.workspaceId });
    const { actCache = {} } = await store.get('actCache');
    actCache[b.workspaceId] = { at: Date.now(), list };
    store.set({ actCache });
    const picked = new Set(b.cards || []);
    const groups = LANES.map(l => ({ ...l, cards: list.filter(c => c.lane === l.code) }))
      .concat([{ code: 'other', label: 'Other', cards: list.filter(c => !LANES.some(l => l.code === c.lane)) }])
      .filter(g => g.cards.length);
    box.innerHTML = groups.map(g => `<div class="lane"><div class="lane-h">${esc(g.label)}</div>${g.cards.map(c =>
      `<label class="pick"><input type="checkbox" data-pick="${i}" value="${esc(c.id)}" ${picked.has(c.id) ? 'checked' : ''}>
        <span>${esc(c.title)}${c.done ? ' <em>(complete)</em>' : ''}</span></label>`).join('')}</div>`).join('')
      || '<div class="hint">No cards on this board.</div>';
  } catch (e) {
    box.innerHTML = `<div class="msg err">${esc(e.message)}</div>`;
  }
}

function renderBoardSelect(selectedWs) {
  const sel = $('#board');
  sel.innerHTML = boards.map(b => `<option value="${esc(b.workspaceId)}">${esc(b.name)}</option>`).join('');
  if (selectedWs && boards.some(b => b.workspaceId === selectedWs)) sel.value = selectedWs;
}
function renderBoards() {
  $('#boards').innerHTML = boards.map((b, i) => {
    const sh = b.sheet || {};
    const opts = CSP_LEVELS.concat(sh.csp && !CSP_LEVELS.includes(sh.csp) ? [sh.csp] : [])
      .map(v => `<option ${v === sh.csp ? 'selected' : ''}>${esc(v)}</option>`).join('');
    const total = (parseFloat(sh.allotted) || 0) + (parseFloat(sh.bucket) || 0);
    return `<li class="${sheetComplete(sh) ? '' : 'missing'}">
      <div class="bhead"><input data-rename="${i}" value="${esc(b.name)}" aria-label="Board name">
        <button class="x" title="Remove board" data-delboard="${i}">✕</button></div>
      <div class="bsheet">
        <label>Sheet customer name<input data-sh="${i}" data-f="customer" value="${esc(sh.customer)}"></label>
        <label>Account #<input data-sh="${i}" data-f="account" value="${esc(sh.account)}"></label>
        <label>CSP level<select data-sh="${i}" data-f="csp"><option value="" ${sh.csp ? '' : 'selected'}>Choose…</option>${opts}</select></label>
        <label>Allotted<input data-sh="${i}" data-f="allotted" type="number" min="0" step="0.5" value="${esc(sh.allotted)}"></label>
        <label>Bucket<input data-sh="${i}" data-f="bucket" type="number" min="0" step="0.5" value="${esc(sh.bucket)}"></label>
        <label>Total<div class="tot" data-tot="${i}">${fmtH(total)}</div></label>
      </div>
      <button class="link acts-toggle" data-acts="${i}">Activities: ${(b.cards || []).length} selected ▸</button>
      <div class="acts" data-actlist="${i}" hidden></div></li>`;
  }).join('') || '<li><div class="hint">No boards yet. Paste a board URL below.</div></li>';
}
async function saveBoards() {
  await store.set({ boards });
  renderBoardSelect($('#board').value);
}
async function addBoard() {
  const url = $('#boardUrl').value.trim();
  const m = $('#setMsg');
  const say = (t, k) => { m.textContent = t; m.className = 'msg' + (k ? ' ' + k : ''); };
  if (!url) return say('Paste a board URL first.', 'err');
  say('Looking up board…');
  try {
    const b = await send({ type: 'resolveBoard', url });
    if (boards.some(x => x.workspaceId === b.workspaceId)) return say(`${b.name} is already in your list.`, 'err');
    boards.push(b);
    await saveBoards();
    renderBoards();
    $('#boardUrl').value = '';
    say(`Added ${b.name}.`, 'ok');
  } catch (e) {
    say(e.message, 'err');
  }
}

// ---------- init ----------
async function init() {
  const s = await store.get(['boards', 'lastBoard', 'lastMode', 'drafts', 'weekCache']);
  const defaults = await send({ type: 'defaultBoards' });
  boards = s.boards || defaults;
  let migrated = !s.boards;
  for (const b of boards) {
    const d = defaults.find(x => x.workspaceId === b.workspaceId);
    if (!b.sheet && d && d.sheet) { b.sheet = d.sheet; migrated = true; }
  }
  if (migrated) await store.set({ boards });
  drafts = s.drafts || {};
  weekCache = s.weekCache || {};
  weekStart = mondayOf(new Date());

  renderBoardSelect(s.lastBoard);
  setMode(s.lastMode === 'admin' ? 'admin' : 'project');
  renderLog();
  loadWeek();
  renderSheetBar();

  document.querySelectorAll('[data-mode]').forEach(b => b.addEventListener('click', () => { if (!busy) setMode(b.dataset.mode); }));
  $('#board').addEventListener('change', () => {
    store.set({ lastBoard: $('#board').value });
    setMsg(''); confirmArmed = false; baseRows = []; refreshGrid(); loadRows(false);
  });
  $('#refresh').addEventListener('click', () => { loadRows(true); loadEntries(true); });
  $('#prevWk').addEventListener('click', () => showWeek(addDays(weekStart, -7)));
  $('#nextWk').addEventListener('click', () => showWeek(addDays(weekStart, 7)));
  $('#thisWk').addEventListener('click', () => showWeek(mondayOf(new Date())));

  $('#gBody').addEventListener('input', e => {
    const t = e.target, d = draft();
    disarm();
    if (t.dataset.cell) {
      const key = t.dataset.cell;
      const [rowId, date] = [key.slice(0, key.lastIndexOf('|')), key.slice(key.lastIndexOf('|') + 1)];
      const c = cellInfo(rowId, date);
      const v = t.value.trim();
      // typing the saved value back (or clearing an empty cell) means "no change"
      if ((c.ex.length === 1 && v !== '' && parseFloat(v) === c.server) || (!c.ex.length && v === '')) delete d.cells[key];
      else d.cells[key] = t.value;
      delete d.errs[key];
      t.className = !Object.prototype.hasOwnProperty.call(d.cells, key) ? (c.ex.length ? 'saved' : '')
        : (c.ex.length && v === '' ? 'del' : 'has');
      updateTotals();
    } else if (t.dataset.note) {
      d.notes[t.dataset.note] = t.value;
    }
    saveDrafts();
  });
  $('#gBody').addEventListener('click', e => {
    const btn = e.target.closest('[data-bill]');
    if (!btn) return;
    const id = btn.dataset.bill;
    const d = draft();
    const nowBillable = d.bill[id] === false;
    if (nowBillable) delete d.bill[id]; else d.bill[id] = false;
    btn.classList.toggle('no', !nowBillable);
    btn.textContent = nowBillable ? 'BILLABLE' : 'NON-BILL';
    saveDrafts();
  });
  $('#gBody').addEventListener('keydown', e => {
    if (e.key !== 'Enter' || !e.target.dataset.cell) return;
    e.preventDefault();
    const td = e.target.closest('td');
    const idx = [...td.parentElement.children].indexOf(td);
    let tr = td.parentElement[e.shiftKey ? 'previousElementSibling' : 'nextElementSibling'];
    while (tr) {
      const inp = tr.children[idx] && tr.children[idx].querySelector('input:not(:disabled)');
      if (inp) { inp.focus(); inp.select(); return; }
      tr = tr[e.shiftKey ? 'previousElementSibling' : 'nextElementSibling'];
    }
  });
  $('#submitBtn').addEventListener('click', submit);
  $('#syncBtn').addEventListener('click', () => { if (!busy) openSync(); });
  $('#syncReload').addEventListener('click', () => loadSync());
  const syncWeek = start => { if (syncBusy) return; syncArmed = null; weekStart = start; loadSync(); };
  $('#syncPrev').addEventListener('click', () => syncWeek(addDays(weekStart, -7)));
  $('#syncNext').addEventListener('click', () => syncWeek(addDays(weekStart, 7)));
  $('#syncThis').addEventListener('click', () => syncWeek(mondayOf(new Date())));
  $('#syncBack').addEventListener('click', () => { syncArmed = null; showView('entry'); refreshGrid(); loadEntries(true); renderLog(); loadWeek(); });
  $('#syncView').addEventListener('click', e => {
    const b = e.target.closest('[data-addb]'); if (b) { const [d, i] = b.dataset.addb.split(':').map(Number); return addToBurnDown(d, i); }
    const j = e.target.closest('[data-addj]'); if (j) { const [d, i] = j.dataset.addj.split(':').map(Number); return addToJourneys(d, i); }
    const x = e.target.closest('[data-del]'); if (x) return syncDelete(x.dataset.del);
    const v = e.target.closest('[data-save]'); if (v) return syncSaveHours(v.dataset.save);
    if (syncArmed && !e.target.closest('button')) { syncArmed = null; renderSync(); }
  });
  $('#syncView').addEventListener('input', e => {
    const k = e.target.dataset.hrs;
    if (k !== undefined) {
      const changed = Math.abs((parseFloat(e.target.value) || 0) - Number(e.target.dataset.orig)) > 1e-9;
      e.target.classList.toggle('has', changed);
      const b = document.querySelector(`[data-save="${k}"]`); if (b) b.hidden = !changed;
      return;
    }
    const id = e.target.dataset.snote; if (id !== undefined) (syncTyped[id] ||= {}).note = e.target.value;
  });
  $('#syncView').addEventListener('change', e => {
    const id = e.target.dataset.scard; if (id !== undefined) (syncTyped[id] ||= {}).cardId = e.target.value;
  });
  $('#clearGrid').addEventListener('click', () => {
    if (busy) return;
    delete drafts[draftKey()];
    saveDrafts();
    disarm();
    setMsg('Unsaved changes cleared.');
    refreshGrid();
  });

  $('#gear').addEventListener('click', () => {
    const toSettings = $('#settingsView').hidden;
    showView(toSettings ? 'settings' : 'entry');
    if (toSettings) {
      renderBoards();
      store.get(['sheetUrl', 'sheetId', 'sheetTab', 'sheetToken']).then(v => {
        $('#sheetLink').value = v.sheetId ? `https://docs.google.com/spreadsheets/d/${v.sheetId}/edit` : '';
        $('#sheetUrl').value = v.sheetUrl || '';
        $('#sheetTab').value = v.sheetTab || '';
        $('#sheetToken').value = v.sheetToken || '';
      });
    }
  });
  $('#back').addEventListener('click', () => { showView('entry'); setMode(mode); });
  $('#addBoard').addEventListener('click', addBoard);
  $('#boardUrl').addEventListener('keydown', e => { if (e.key === 'Enter') addBoard(); });
  $('#boards').addEventListener('change', e => {
    const i = e.target.dataset.rename;
    if (i !== undefined && e.target.value.trim()) { boards[i].name = e.target.value.trim(); saveBoards(); }
  });
  $('#boards').addEventListener('input', e => {
    const i = e.target.dataset.sh, f = e.target.dataset.f;
    if (i === undefined) return;
    const b = boards[i];
    b.sheet = { ...(b.sheet || {}), [f]: e.target.value.trim() };
    const sh = b.sheet;
    const tot = document.querySelector(`[data-tot="${i}"]`);
    if (tot) tot.textContent = fmtH((parseFloat(sh.allotted) || 0) + (parseFloat(sh.bucket) || 0));
    e.target.closest('li').classList.toggle('missing', !sheetComplete(sh));
    store.set({ boards });
  });
  $('#sheetTest').addEventListener('click', async () => {
    const m = $('#sheetMsg');
    const link = $('#sheetLink').value.trim();
    const idMatch = link.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]{20,})/) || link.match(/^([a-zA-Z0-9_-]{20,})$/);
    if (!idMatch) { m.className = 'msg err'; m.textContent = 'Paste the Burn Down sheet\u2019s link (docs.google.com/spreadsheets/d/…) or its ID.'; return; }
    await store.set({ sheetId: idMatch[1], sheetUrl: $('#sheetUrl').value.trim(), sheetTab: $('#sheetTab').value.trim(), sheetToken: $('#sheetToken').value.trim() });
    m.className = 'msg'; m.textContent = 'Testing…';
    try {
      const r = await send({ type: 'sheetTest' });
      m.className = 'msg ok'; m.textContent = `✓ Connected to "${r.tab}" — next empty row is ${r.nextRow}.`;
    } catch (err) {
      m.className = 'msg err'; m.textContent = err.message;
    }
  });
  $('#sheetRetry').addEventListener('click', retrySheet);
  $('#boards').addEventListener('click', e => {
    const t = e.target.closest('[data-acts]');
    if (t) toggleActs(Number(t.dataset.acts), t);
  });
  $('#boards').addEventListener('change', e => {
    const i = e.target.dataset.pick;
    if (i === undefined) return;
    const b = boards[i];
    const set = new Set(b.cards || []);
    if (e.target.checked) set.add(e.target.value); else set.delete(e.target.value);
    b.cards = [...set];
    store.set({ boards });
    const btn = document.querySelector(`[data-acts="${i}"]`);
    if (btn) btn.textContent = `Activities: ${b.cards.length} selected ▾`;
  });
  $('#boards').addEventListener('click', e => {
    const i = e.target.dataset.delboard;
    if (i !== undefined) { boards.splice(Number(i), 1); saveBoards(); renderBoards(); }
  });
}

init();

// The side panel stays open, so refresh when you come back to it
let lastFocusLoad = Date.now();
function refreshOnReturn() {
  if (document.visibilityState !== 'visible' || busy || Date.now() - lastFocusLoad < 30000) return;
  lastFocusLoad = Date.now();
  loadEntries(true);
  loadWeek();
}
document.addEventListener('visibilitychange', refreshOnReturn);
window.addEventListener('focus', refreshOnReturn);
