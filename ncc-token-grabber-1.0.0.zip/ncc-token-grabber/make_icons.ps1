Add-Type -AssemblyName System.Drawing
$dir = Join-Path $PSScriptRoot 'icons'
New-Item -ItemType Directory -Force -Path $dir | Out-Null

function New-Icon([int]$size, [string]$path) {
  $bmp = New-Object System.Drawing.Bitmap($size, $size)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = 'AntiAlias'
  $g.Clear([System.Drawing.Color]::Transparent)

  # Rounded blue background
  $pad = [Math]::Max(1, [int]($size * 0.06))
  $rect = New-Object System.Drawing.Rectangle($pad, $pad, ($size - 2 * $pad), ($size - 2 * $pad))
  $radius = [int]($size * 0.22)
  $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = $radius * 2
  $gp.AddArc($rect.X, $rect.Y, $d, $d, 180, 90)
  $gp.AddArc($rect.Right - $d, $rect.Y, $d, $d, 270, 90)
  $gp.AddArc($rect.Right - $d, $rect.Bottom - $d, $d, $d, 0, 90)
  $gp.AddArc($rect.X, $rect.Bottom - $d, $d, $d, 90, 90)
  $gp.CloseFigure()
  $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(11, 95, 255))
  $g.FillPath($brush, $gp)

  # White key: bow (ring) top-left, shaft to bottom-right, two teeth
  $penW = [Math]::Max(1.0, $size * 0.09)
  $white = New-Object System.Drawing.Pen([System.Drawing.Color]::White, $penW)
  $white.StartCap = 'Round'; $white.EndCap = 'Round'
  $bowSize = $size * 0.30
  $bx = $size * 0.24; $by = $size * 0.24
  $g.DrawEllipse($white, ($bx - $bowSize / 2), ($by - $bowSize / 2), $bowSize, $bowSize)
  $g.DrawLine($white, [single]($bx + $bowSize * 0.32), [single]($by + $bowSize * 0.32), [single]($size * 0.74), [single]($size * 0.74))
  $g.DrawLine($white, [single]($size * 0.60), [single]($size * 0.62), [single]($size * 0.72), [single]($size * 0.50))
  $g.DrawLine($white, [single]($size * 0.72), [single]($size * 0.74), [single]($size * 0.84), [single]($size * 0.62))

  $white.Dispose(); $brush.Dispose(); $gp.Dispose(); $g.Dispose()
  $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
}

foreach ($s in 16, 32, 48, 128) { New-Icon $s (Join-Path $dir "icon$s.png") }
Get-ChildItem $dir | Select-Object Name, Length | Format-Table -AutoSize
