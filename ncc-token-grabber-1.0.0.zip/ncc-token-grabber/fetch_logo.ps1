$dir = Join-Path $PSScriptRoot 'icons'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$urls = @(
  'https://www.nextiva.com/apple-touch-icon.png',
  'https://www.nextiva.com/apple-touch-icon-precomposed.png',
  'https://www.nextiva.com/favicon-192x192.png',
  'https://www.nextiva.com/favicon-96x96.png',
  'https://www.nextiva.com/favicon-32x32.png',
  'https://www.nextiva.com/favicon.ico',
  'https://help.nextiva.com/favicon.ico'
)
foreach ($u in $urls) {
  try {
    $name = 'src_' + ($u.Split('/')[-1])
    $out = Join-Path $dir $name
    Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $out -ErrorAction Stop
    $len = (Get-Item $out).Length
    Write-Output ("OK   $u  ->  $name  $len bytes")
  }
  catch {
    Write-Output ("FAIL $u  ->  " + $_.Exception.Message)
  }
}
