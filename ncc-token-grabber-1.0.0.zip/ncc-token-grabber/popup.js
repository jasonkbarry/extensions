"use strict";

const statusEl = document.getElementById("status");
const metaEl = document.getElementById("meta");
const tokenEl = document.getElementById("token");
const showBtn = document.getElementById("show");
const titleEl = document.getElementById("title");

let currentToken = null;
let currentContext = null;

// When the tab is the bare thrio.io/lioncc alias there's no subdomain to read the
// cluster from, so fall back to this tenantId -> cluster map. Add entries as needed.
const TENANT_CLUSTER = {
  focalpointcx: "mancity",
  nextivase3: "nextiva",
  bluebaytravel: "europe",
};

/** Runs in the page context: scan localStorage, sessionStorage, then cookies for a
 * JWT. Returns { token } (null token if none found). */
function scrapeToken() {
  const looksLikeJwt = (v) =>
    typeof v === "string" && /^eyJ[\w-]+\.[\w-]+\.[\w-]+$/.test(v.trim());

  const scanStore = (store) => {
    for (let i = 0; i < store.length; i++) {
      const raw = store.getItem(store.key(i));
      if (looksLikeJwt(raw)) return raw.trim();
      // Token sometimes lives inside a JSON blob.
      if (raw && raw.includes("eyJ")) {
        try {
          const obj = JSON.parse(raw);
          for (const val of Object.values(obj)) {
            if (looksLikeJwt(val)) return String(val).trim();
          }
        } catch (_) {
          /* not JSON */
        }
      }
    }
    return null;
  };

  let token = scanStore(window.localStorage) || scanStore(window.sessionStorage);

  if (!token) {
    const cookieVal = document.cookie
      .split(";")
      .map((c) => c.trim().split("=").slice(1).join("="))
      .find((v) => looksLikeJwt(v));
    if (cookieVal) token = cookieVal.trim();
  }

  return { token };
}

/** Runs in the page context: fetch the tenant object and return its display name.
 * Uses the page's own origin/auth so it works even when the popup can't. */
async function fetchTenantName(apiBase, tenantId, token) {
  try {
    const r = await fetch(apiBase + "/types/tenant/" + tenantId, {
      headers: { Authorization: token },
      credentials: "include",
    });
    if (!r.ok) return null;
    const o = await r.json();
    return o && typeof o.name === "string" && o.name.trim() ? o.name.trim() : null;
  } catch (_) {
    return null;
  }
}

/** Decode the JWT payload (without verifying the signature). */
function decodePayload(token) {
  try {
    const part = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(decodeURIComponent(escape(atob(part))));
  } catch (_) {
    return null;
  }
}

/** Decode the JWT payload's exp claim without verifying the signature. */
function decodeExp(token) {
  const json = decodePayload(token);
  return json && typeof json.exp === "number" ? json.exp : null;
}

/** Pull the tenant slug from the JWT payload. */
function extractTenant(token) {
  const json = decodePayload(token);
  if (!json) return null;
  // tenantId is the authoritative NCC tenant slug (e.g. bluebaytravel, focalpointcx).
  if (json.tenantId) return String(json.tenantId);
  const fallback = ["tenant_id", "tenantName", "tenant_name", "tenant", "tid"];
  for (const key of fallback) {
    if (json[key]) return String(json[key]);
  }
  return null;
}

/** The cluster is the *.thrio.io subdomain, or null on the bare thrio.io alias. */
function extractCluster(url) {
  try {
    const host = new URL(url).hostname;
    const m = host.match(/^([^.]+)\.thrio\.io$/i);
    return m ? m[1] : null;
  } catch (_) {
    return null;
  }
}

/** API base for NCC data calls, derived from the tab's origin. */
function extractApiBase(url) {
  try {
    return new URL(url).origin + "/data/api";
  } catch (_) {
    return null;
  }
}

function setStatus(msg, kind) {
  statusEl.textContent = msg;
  statusEl.className = kind || "";
}

async function loadToken() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !/^https:\/\/([^/]*\.)?thrio\.io\//.test(tab.url || "")) {
    setStatus("Open an NCC (thrio.io) tab first.", "err");
    return;
  }

  let results;
  try {
    results = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: scrapeToken,
    });
  } catch (e) {
    setStatus("Could not read the page: " + (e && e.message), "err");
    return;
  }

  // Take the first frame result that yielded a JWT (top document or a sub-frame).
  const scraped = (results || [])
    .map((r) => r && r.result)
    .filter((v) => v && typeof v === "object");
  const hit = scraped.find((v) => typeof v.token === "string" && v.token.length > 0);
  currentToken = (hit && hit.token) || null;

  if (!currentToken) {
    setStatus("No JWT found on this tab.", "err");
    return;
  }

  const tenant = extractTenant(currentToken);
  // Cluster from the subdomain when present, else the tenant->cluster fallback map.
  const cluster =
    extractCluster(tab.url) || (tenant && TENANT_CLUSTER[tenant]) || null;

  // Look up the tenant's display name from the NCC API, in the page context so the
  // origin, cookies, and Authorization header all match the live session.
  let tenantName = null;
  if (tenant) {
    try {
      const apiBase = new URL(tab.url).origin + "/data/api";
      const nres = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: fetchTenantName,
        args: [apiBase, tenant, currentToken],
      });
      tenantName = (nres && nres[0] && nres[0].result) || null;
    } catch (_) {
      /* leave tenantName null; the bundle just omits the name line */
    }
  }

  // Prefer a real tenant name; append the cluster region for context.
  const parts = [];
  if (tenantName) parts.push(tenantName);
  if (tenant) parts.push(tenant);
  if (cluster) parts.push(cluster);
  titleEl.textContent = parts.length
    ? "NCC Token \u2014 " + parts.join(" \u00b7 ")
    : "NCC Token Grabber";
  titleEl.title = parts.length
    ? [tenantName && "name", "tenant", cluster && "cluster"]
        .filter(Boolean)
        .join(" \u00b7 ")
    : "";

  const exp = decodeExp(currentToken);
  let expiresText = null;
  let expired = false;
  if (exp) {
    const when = new Date(exp * 1000);
    expired = when.getTime() < Date.now();
    expiresText = when.toLocaleString();
    metaEl.textContent =
      (expired ? "EXPIRED at " : "Expires ") + expiresText;
    setStatus(
      expired ? "Token found but expired." : "Token found.",
      expired ? "err" : "ok"
    );
  } else {
    setStatus("Token found.", "ok");
  }

  currentContext = {
    tenantName,
    tenant,
    cluster,
    baseUrl: cluster
      ? `https://${cluster}.thrio.io`
      : (extractApiBase(tab.url) || "").replace(/\/data\/api$/, ""),
    expires: expiresText,
    expired,
    token: currentToken,
  };

  tokenEl.value = currentToken;

  // Auto-copy so the bundle is on the clipboard the moment the popup opens.
  await copyContext();
}

/** Copy the current context bundle to the clipboard. */
async function copyContext() {
  if (!currentContext) return;
  try {
    await navigator.clipboard.writeText(buildBundle(currentContext));
    setStatus("Context copied to clipboard.", "ok");
  } catch (e) {
    setStatus("Auto-copy failed: " + e.message, "err");
  }
}

/** Build the paste-ready bundle: Tenant Name, TenantID, Cluster, URL, Token. */
function buildBundle(ctx) {
  const lines = [];
  if (ctx.tenantName) lines.push("Tenant Name: " + ctx.tenantName);
  if (ctx.tenant) lines.push("TenantID: " + ctx.tenant);
  if (ctx.cluster) lines.push("Cluster: " + ctx.cluster);
  if (ctx.baseUrl) lines.push("URL: " + ctx.baseUrl);
  lines.push("Token: " + ctx.token);
  return lines.join("\n");
}

showBtn.addEventListener("click", () => {
  const showing = tokenEl.style.display === "block";
  if (!showing) {
    // Reveal the clean bundle: Tenant, URL, and the token (no raw claims).
    tokenEl.value = currentContext
      ? buildBundle(currentContext)
      : currentToken || "";
  }
  tokenEl.style.display = showing ? "none" : "block";
  showBtn.textContent = showing ? "Show" : "Hide";
});

loadToken().catch((e) => {
  setStatus("Error: " + (e && e.message ? e.message : String(e)), "err");
});
