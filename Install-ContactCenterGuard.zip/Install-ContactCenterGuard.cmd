@echo off
title Contact Center Guard installer
rem Installs or updates Contact Center Guard. Double-click to run.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$x='contact-center-guard'; irm https://jasonkbarry.github.io/extensions/install.txt | iex"
