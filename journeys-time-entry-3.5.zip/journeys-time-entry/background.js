// Journeys Time Entry — background service worker
// Talks to the Journeys API (onboarding.nextiva.com) using your signed-in session.

const BASE = 'https://onboarding.nextiva.com';

// Boards are added by each user in ⚙ settings (paste a board URL).
const DEFAULT_BOARDS = [];

const ADMIN_LABELS = {
  pto_holiday: 'FTO / Holiday',
  internal_meeting: 'Internal meeting',
  admin_email: 'Admin / email',
  training: 'Training',
  internal_project: 'Internal project',
  npi_management: 'NPI management'
};

// ---------- setup ----------
chrome.runtime.onInstalled.addListener(async () => {
  const { boards, sheetTab } = await chrome.storage.local.get(['boards', 'sheetTab']);
  if (!boards) await chrome.storage.local.set({ boards: DEFAULT_BOARDS });
  else {
    // add Burn Down defaults to boards saved by older versions
    let changed = false;
    for (const b of boards) {
      const d = DEFAULT_BOARDS.find(x => x.workspaceId === b.workspaceId);
      if (!b.sheet && d) { b.sheet = d.sheet; changed = true; }
    }
    if (changed) await chrome.storage.local.set({ boards });
  }
  scheduleReminder();
});
chrome.runtime.onStartup.addListener(scheduleReminder);

// ---------- updates ----------
// 1) Self-reload: when the installer copies new files into this folder, the manifest on disk has a new
//    version. Reload so Chrome picks up the new code (no need to click reload in chrome://extensions).
async function checkDiskVersion() {
  try {
    const m = await fetch(chrome.runtime.getURL('manifest.json') + '?t=' + Date.now(), { cache: 'no-store' }).then(r => r.json());
    if (m.version && m.version !== chrome.runtime.getManifest().version) chrome.runtime.reload();
  } catch (e) { /* manifest mid-copy; try again next time */ }
}
// 2) Update available: compare with the version published on the extensions site.
const UPDATE_INFO_URL = 'https://jasonkbarry.github.io/extensions/journeys-time-entry.json';
const verNum = v => String(v || '0').split('.').map(n => parseInt(n, 10) || 0);
const newer = (a, b) => { const x = verNum(a), y = verNum(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function checkForUpdate() {
  try {
    const info = await fetch(UPDATE_INFO_URL + '?t=' + Date.now(), { cache: 'no-store' }).then(r => r.json());
    const latest = newer(info.version, chrome.runtime.getManifest().version) ? info : null;
    await chrome.storage.local.set({ updateInfo: latest, updateCheckedAt: Date.now() });
    return latest;
  } catch (e) { return null; }
}
chrome.alarms.get('diskCheck').then(a => { if (!a) chrome.alarms.create('diskCheck', { periodInMinutes: 1 }); });
chrome.alarms.get('updateCheck').then(a => { if (!a) chrome.alarms.create('updateCheck', { periodInMinutes: 360, delayInMinutes: 1 }); });
chrome.alarms.onAlarm.addListener(a => {
  if (a.name === 'diskCheck') checkDiskVersion();
  if (a.name === 'updateCheck') checkForUpdate();
});
checkDiskVersion();

// Open in Chrome's side panel (stays open while switching tabs) when the toolbar icon is clicked
function useSidePanel() {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
}
chrome.runtime.onInstalled.addListener(useSidePanel);
chrome.runtime.onStartup.addListener(useSidePanel);
useSidePanel();

// ---------- Wednesday reminder (4 PM local, time is due at 7 PM) ----------
function nextWednesday4pm() {
  const now = new Date();
  const t = new Date(now);
  t.setHours(16, 0, 0, 0);
  t.setDate(now.getDate() + ((3 - now.getDay() + 7) % 7));
  if (t <= now) t.setDate(t.getDate() + 7);
  return t.getTime();
}
async function scheduleReminder() {
  const a = await chrome.alarms.get('wedReminder');
  if (!a) chrome.alarms.create('wedReminder', { when: nextWednesday4pm() });
}
chrome.alarms.onAlarm.addListener(a => {
  if (a.name !== 'wedReminder') return;
  chrome.notifications.create('wedReminder', {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'Time entry due at 7 PM',
    message: 'Your Journeys time needs to be entered by 7 PM today.',
    priority: 2
  });
  chrome.alarms.create('wedReminder', { when: nextWednesday4pm() });
});
chrome.notifications.onClicked.addListener(id => {
  if (id === 'wedReminder') chrome.tabs.create({ url: BASE + '/employee/pm/timesheet' });
});

// ---------- API helpers ----------
const ymd = d => {
  const z = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
};
const parse = t => { try { return JSON.parse(t); } catch { return null; } };

async function directFetch(path, opts) {
  const r = await fetch(BASE + path, { credentials: 'include', ...opts });
  const text = await r.text();
  return { ok: r.ok, status: r.status, text, data: parse(text) };
}

function waitForLoad(tabId) {
  return new Promise(resolve => {
    let timer;
    const listener = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const done = () => {
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      setTimeout(resolve, 1500);
    };
    timer = setTimeout(done, 25000);
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// Fallback: run the request inside a Journeys tab so it uses the page's own session.
async function tabFetch(path, opts) {
  let [tab] = await chrome.tabs.query({ url: BASE + '/*' });
  let created = false;
  if (!tab) {
    tab = await chrome.tabs.create({ url: BASE + '/employee/pm/my-day', active: false });
    created = true;
    await waitForLoad(tab.id);
    tab = await chrome.tabs.get(tab.id);
    if (!tab.url || !tab.url.startsWith(BASE)) {
      await chrome.tabs.update(tab.id, { active: true });
      throw new Error('Sign in to Journeys in the tab that just opened, then try again.');
    }
  }
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: async (p, o) => {
        let r = await fetch(p, { credentials: 'include', ...o });
        if (r.status === 401) {
          // session cookie expired while idle: renew it the way the Journeys page does, then retry once
          try { await fetch('/api/wizard/session/refresh', { method: 'POST', credentials: 'include' }); } catch (e) {}
          r = await fetch(p, { credentials: 'include', ...o });
        }
        return { ok: r.ok, status: r.status, text: await r.text() };
      },
      args: [path, opts || {}]
    });
    const v = res.result;
    return { ...v, data: parse(v.text) };
  } finally {
    if (created) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

// Journeys signs in with an httpOnly session cookie that expires when idle; the web app renews it with this call.
async function refreshSession() {
  try { const r = await fetch(BASE + '/api/wizard/session/refresh', { method: 'POST', credentials: 'include' }); return r.ok; }
  catch (e) { return false; }
}

async function api(path, opts = {}) {
  let r = null;
  try { r = await directFetch(path, opts); } catch (e) { r = null; }
  if (r && r.status === 401 && await refreshSession()) {
    try { r = await directFetch(path, opts); } catch (e) { r = null; }
  }
  const htmlInsteadOfJson = r && r.ok && r.data === null && r.text.trim().startsWith('<');
  if (!r || r.status === 401 || r.status === 403 || htmlInsteadOfJson) {
    r = await tabFetch(path, opts);
  }
  if (!r.ok) {
    if (r.status === 401) {
      throw new Error('Not signed in to Journeys. Sign in (or open any Journeys page so it renews your session), then try again.');
    }
    if (r.status === 403) {
      throw new Error('Journeys refused this request (HTTP 403). You may not have access to this board, or your Journeys session needs a sign-in.');
    }
    const d = r.data || {};
    const msg = d.message || d.error || d.detail || `HTTP ${r.status}`;
    throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
  }
  return r.data;
}

// ---------- operations ----------
async function getActivities(workspaceId) {
  const b = await api(`/api/pm/post-onboarding/${workspaceId}/board?laneLimit=60&today=${ymd(new Date())}`);
  return (b.cards || [])
    .filter(c => !c.isArchived)
    .sort((a, c) => (a.position ?? 0) - (c.position ?? 0))
    .map(c => ({ id: c.id, title: c.title, lane: c.laneCode, done: !!c.isComplete }));
}

async function getPins() {
  const p = await api('/api/pm/me/timesheet-pins');
  return (p.pins || [])
    .filter(x => x.kind === 'non_project' && x.available !== false)
    .map(x => {
      const key = x.title || String(x.rowKey || '').replace('nonproject:', '');
      const label = ADMIN_LABELS[key] || key.replace(/_/g, ' ').replace(/^./, s => s.toUpperCase());
      return { key, label };
    });
}

async function resolveBoard(url) {
  const m = String(url).match(/accounts\/([0-9a-f-]{36})\/projects\/([0-9a-f-]{36})/i);
  if (!m) throw new Error('That doesn\u2019t look like a Journeys board URL (it needs /accounts/\u2026/projects/\u2026).');
  const [, accountId, projectId] = m;
  const p = await api(`/api/pm/projects/${projectId}/post-onboarding`);
  const workspaceId = p && p.workspace && p.workspace.id;
  if (!workspaceId) throw new Error('No post-onboarding board was found for that project.');
  let name = 'Board';
  try {
    const a = await api('/api/pm/accounts');
    const acct = (a.accounts || []).find(x => x.id === accountId);
    if (acct) name = acct.name;
  } catch { /* keep default name */ }
  return { name, accountId, projectId, workspaceId };
}

async function getWeek() {
  const now = new Date();
  const mon = new Date(now);
  mon.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const sun = new Date(mon);
  sun.setDate(mon.getDate() + 6);
  const te = await api(`/api/pm/time-entries?dateFrom=${ymd(mon)}&dateTo=${ymd(sun)}`);
  const entries = te.entries || [];
  const today = ymd(now);
  const sum = arr => arr.reduce((s, e) => s + (Number(e.hours) || 0), 0);
  return {
    week: sum(entries),
    today: sum(entries.filter(e => e.entryDate === today)),
    billable: sum(entries.filter(e => e.billable))
  };
}

async function getWeekEntries(from, to) {
  const te = await api(`/api/pm/time-entries?dateFrom=${from}&dateTo=${to}`);
  return (te.entries || []).map(e => ({
    id: e.id,
    date: e.entryDate,
    hours: Number(e.hours) || 0,
    billable: !!e.billable,
    notes: e.notes || '',
    cardId: e.postOnboardingCardId || null,
    workspaceId: e.postOnboardingWorkspaceId || null,
    category: e.nonProjectCategory || null
  }));
}

// ---------- submission ----------
async function submitOne(item) {
  const headers = { 'Content-Type': 'application/json' };
  if (item.op === 'update') {
    return api(`/api/pm/time-entries/${item.entryId}`, { method: 'PATCH', headers, body: JSON.stringify({ hours: item.hours }) });
  }
  if (item.op === 'delete') {
    return api(`/api/pm/time-entries/${item.entryId}`, { method: 'DELETE' });
  }
  if (item.kind === 'project') {
    return api(`/api/pm/post-onboarding/cards/${item.cardId}/time-entries`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        entryDate: item.date,
        hours: item.hours,
        billingCategory: 'technical',
        billable: !!item.billable,
        notes: item.notes || null
      })
    });
  }
  return api('/api/pm/time-entries', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      category: item.category,
      entryDate: item.date,
      hours: item.hours,
      notes: item.notes || null,
      ticketReference: null
    })
  });
}

// ---------- Burn Down sheet (Apps Script web app) ----------
// Team defaults: the shared Burn Down script (Workspace-only access) and sheet. Used unless the person sets their own in ⚙.
const TEAM_SHEET = { url: 'https://script.google.com/a/macros/nextiva.com/s/AKfycby3oTXyIdZPIZwy_AGn0aYcAEZ0TcIioAJAOay32uij6acTn-6LJb5AwQgK2Imvoyje/exec', sheetId: '1iha8jnMGIpiUaAMKygDtf8hhpo9u0cGdNdq289iCotY' };
const hasTeamDefault = () => /^https:\/\/script\.google\.com\//.test(TEAM_SHEET.url);

async function sheetSettings() {
  const v = await chrome.storage.local.get(['sheetUrl', 'sheetId', 'sheetTab', 'sheetToken']);
  const team = hasTeamDefault() && !v.sheetUrl && !v.sheetId;
  return { sheetUrl: v.sheetUrl || (team ? TEAM_SHEET.url : ''), sheetId: v.sheetId || (team ? TEAM_SHEET.sheetId : ''),
    sheetTab: v.sheetTab || '', sheetToken: v.sheetToken || '', team };
}

// Find the person's tab from their work email (jane.smith@ -> "Jane Smith") and remember it
async function autoTab(sheetUrl, sheetId, sheetToken) {
  try {
    const r = await fetch(sheetUrl, { method: 'POST', credentials: 'include', redirect: 'follow', headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'tabs', sheetId, token: sheetToken }) });
    const d = parse(await r.text());
    if (!d || !d.ok) return '';
    const want = String(d.you || '').split('@')[0].replace(/[._-]+/g, ' ').trim().toLowerCase();
    const tab = want && (d.tabs || []).find(t => t.trim().toLowerCase() === want);
    if (tab) await chrome.storage.local.set({ sheetTab: tab });
    return tab || '';
  } catch (e) { return ''; }
}

async function sheetCall(body, needTab = true) {
  let { sheetUrl, sheetId, sheetTab, sheetToken } = await sheetSettings();
  if (needTab && !sheetTab && sheetUrl && sheetId) sheetTab = await autoTab(sheetUrl, sheetId, sheetToken);
  if (!sheetUrl) throw new Error('Burn Down sheet web app URL is not set (⚙ settings). Paste your team setup code there.');
  if (!sheetId) throw new Error('Burn Down sheet link is not set (⚙ settings). Paste your team setup code there.');
  if (needTab && !sheetTab) throw new Error('Burn Down tab name is not set (⚙ settings).');
  let r;
  try {
    r = await fetch(sheetUrl, {
      method: 'POST',
      credentials: 'include',
      redirect: 'follow',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ sheetId, tab: sheetTab, token: sheetToken, ...body })
    });
  } catch (e) {
    throw new Error('Could not reach the Burn Down web app (' + e.message + ').');
  }
  const text = await r.text();
  const data = parse(text);
  if (!data) {
    if (/accounts\.google\.com|ServiceLogin|<html/i.test(text)) {
      throw new Error('Google sign-in needed for the Burn Down web app. Open the web app URL once in Chrome while signed in to the Google account that owns it.');
    }
    throw new Error(`Burn Down web app returned HTTP ${r.status}.`);
  }
  if (!data.ok) {
    const err = String(data.error || 'unknown error');
    if (/Illegal spreadsheet id or key/i.test(err) && /docs\.google|\/edit|\/d\//i.test(err)) {
      throw new Error('Your Burn Down Apps Script is an old version: it ignores the Sheet link here and uses a full sheet address typed into the script itself. '
        + 'Fix: paste the latest BurnDown.gs into your Apps Script, save, then Deploy → Manage deployments → ✏ → Version: New version → Deploy.');
    }
    throw new Error('Burn Down sheet: ' + err);
  }
  return data;
}

async function sheetAppend(rows) {
  if (!rows.length) return { ok: true, written: [] };
  const { sheetPending = [] } = await chrome.storage.local.get('sheetPending');
  try {
    const data = await sheetCall({ action: 'append', rows });
    return { ok: true, written: data.written || [] };
  } catch (e) {
    await chrome.storage.local.set({ sheetPending: sheetPending.concat(rows) });
    return { ok: false, error: e.message, pending: sheetPending.length + rows.length };
  }
}

async function sheetList({ customer, from, to }) {
  const data = await sheetCall({ action: 'list', customer, from, to });
  if (!Array.isArray(data.rows)) {
    throw new Error('Your Burn Down Apps Script is out of date. Paste in the latest BurnDown.gs and redeploy (Manage deployments → ✏ → Version: New version).');
  }
  return data.rows;
}

async function sheetZero(rows) {
  const data = await sheetCall({ action: 'zero', rows });
  if (!Array.isArray(data.zeroed)) {
    throw new Error('Your Burn Down Apps Script is out of date, so it could not set deleted hours to 0. Paste in the latest BurnDown.gs and redeploy (Manage deployments → ✏ → Version: New version).');
  }
  return data.zeroed;
}

async function sheetSetHours(rows) {
  const data = await sheetCall({ action: 'sethours', rows });
  if (!Array.isArray(data.updated)) {
    throw new Error('Your Burn Down Apps Script is out of date, so it can\u2019t change hours. Paste in the latest BurnDown.gs and redeploy (Manage deployments → ✏ → Version: New version).');
  }
  return data.updated;
}

async function sheetCustomers() {
  const data = await sheetCall({ action: 'customers' });
  if (!Array.isArray(data.customers)) throw new Error('Update your Burn Down Apps Script to get customer suggestions (paste the latest BurnDown.gs and redeploy as a New version).');
  return data.customers;
}

async function sheetRetry() {
  const { sheetPending = [] } = await chrome.storage.local.get('sheetPending');
  if (!sheetPending.length) return { ok: true, written: [], zeroed: [] };
  const appends = sheetPending.filter(r => r.op !== 'zero');
  const zeros = sheetPending.filter(r => r.op === 'zero');
  const data = appends.length ? await sheetCall({ action: 'append', rows: appends }) : { written: [] };
  await chrome.storage.local.set({ sheetPending: zeros });
  const zeroed = zeros.length ? await sheetZero(zeros) : [];
  await chrome.storage.local.set({ sheetPending: [] });
  return { ok: true, written: data.written || [], zeroed };
}

let submitting = false;
async function submitItems(items) {
  if (submitting) throw new Error('A submit is already in progress.');
  submitting = true;
  const results = {};
  try {
    for (const item of items) {
      try {
        await submitOne(item);
        results[item.id] = { ok: true };
        const { log = [] } = await chrome.storage.local.get('log');
        log.unshift({ ...item, doneAt: Date.now() });
        await chrome.storage.local.set({ log: log.slice(0, 40) });
      } catch (e) {
        results[item.id] = { ok: false, error: e.message || String(e) };
      }
    }
    // Burn Down sheet: one row per billable entry that was just created in Journeys
    const rows = items.filter(it => results[it.id] && results[it.id].ok && it.sheetRow)
      .map(it => ({ ...it.sheetRow, ref: it.id }));
    const sheet = rows.length ? await sheetAppend(rows) : null;

    // Deleted billable entries: set the matching Burn Down row's hours to 0 (row is kept)
    const zeros = items.filter(it => it.op === 'delete' && results[it.id] && results[it.id].ok && it.sheetZero)
      .map(it => ({ ...it.sheetZero, ref: it.id }));
    let zero = null;
    if (zeros.length) {
      try {
        zero = { ok: true, zeroed: await sheetZero(zeros) };
      } catch (e) {
        const { sheetPending = [] } = await chrome.storage.local.get('sheetPending');
        await chrome.storage.local.set({ sheetPending: sheetPending.concat(zeros.map(z => ({ ...z, op: 'zero' }))) });
        zero = { ok: false, error: e.message };
      }
    }
    return { results, sheet, zero };
  } finally {
    submitting = false;
  }
}

// ---------- messaging ----------
async function handle(msg) {
  switch (msg.type) {
    case 'activities': return getActivities(msg.workspaceId);
    case 'pins': return getPins();
    case 'resolveBoard': return resolveBoard(msg.url);
    case 'week': return getWeek();
    case 'weekEntries': return getWeekEntries(msg.from, msg.to);
    case 'submitItems': return submitItems(msg.items || []);
    case 'sheetTest': return sheetCall({ action: 'ping' });
    case 'sheetRetry': return sheetRetry();
    case 'sheetList': return sheetList(msg);
    case 'sheetZeroRows': return sheetZero(msg.rows || []);
    case 'sheetSetHours': return sheetSetHours(msg.rows || []);
    case 'sheetCustomers': return sheetCustomers();
    case 'sheetTabs': return sheetCall({ action: 'tabs' }, false);
    case 'sheetSettings': return sheetSettings();
    case 'sheetAddRows': return sheetCall({ action: 'append', rows: msg.rows || [] });
    case 'defaultBoards': return DEFAULT_BOARDS;
    case 'checkDisk': return checkDiskVersion();
    case 'checkUpdate': return checkForUpdate();
    default: throw new Error('Unknown request: ' + msg.type);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg).then(
    result => sendResponse({ ok: true, result }),
    err => sendResponse({ ok: false, error: err.message || String(err) })
  );
  return true;
});
