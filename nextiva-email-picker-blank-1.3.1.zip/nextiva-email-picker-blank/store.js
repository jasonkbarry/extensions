// Shared storage helpers (used by the content script and the toolbar popup).
const NEP_KEY = "nepEmails";

async function nepLoad() {
  const got = await chrome.storage.local.get(NEP_KEY);
  if (!Array.isArray(got[NEP_KEY])) {
    await chrome.storage.local.set({ [NEP_KEY]: NEP_DEFAULT_EMAILS });
    return NEP_DEFAULT_EMAILS.slice();
  }
  return got[NEP_KEY];
}

async function nepSave(list) {
  await chrome.storage.local.set({ [NEP_KEY]: list });
}

async function nepAdd(entry) {
  const list = await nepLoad();
  const email = entry.email.trim();
  if (list.some(e => e.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("That email is already in your list.");
  }
  list.push({ partner: entry.partner.trim(), tenant: entry.tenant.trim(), email });
  await nepSave(list);
  return list;
}

async function nepRemove(email) {
  const list = (await nepLoad()).filter(e => e.email !== email);
  await nepSave(list);
  return list;
}

function nepGroup(list, filter) {
  const q = (filter || "").toLowerCase().trim();
  const groups = {};
  for (const e of list) {
    const hay = `${e.partner} ${e.tenant} ${e.email}`.toLowerCase();
    if (q && !hay.includes(q)) continue;
    (groups[e.partner] = groups[e.partner] || []).push(e);
  }
  return Object.keys(groups)
    .sort((a, b) => a.localeCompare(b))
    .map(p => ({ partner: p, items: groups[p].sort((a, b) => a.tenant.localeCompare(b.tenant)) }));
}

function nepValidEmail(s) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((s || "").trim());
}
