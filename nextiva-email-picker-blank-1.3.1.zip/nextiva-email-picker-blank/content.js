// Nextiva Login Email Picker — content script for thrio.io pages.
(() => {
  if (window.__nepLoaded) return;
  window.__nepLoaded = true;

  const handled = new WeakSet();   // fields we've already auto-opened for
  let host = null;                 // overlay shadow host
  let activeField = null;

  // ---------- Login field detection ----------
  const EMAIL_HINT = /e-?mail|user(name)?|login|account/i;

  function visible(el) {
    if (!el || el.disabled || el.readOnly) return false;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.visibility !== "hidden" && cs.display !== "none";
  }

  // A sign-in page is one with a visible password box. Nothing else counts.
  function loginPassword() {
    return [...document.querySelectorAll('input[type="password"]')].find(visible) || null;
  }

  // Text near the input (e.g. a caption like "Email" that isn't linked with for=).
  function nearbyText(i) {
    let p = i.parentElement;
    for (let k = 0; k < 4 && p; k++, p = p.parentElement) {
      if (p.querySelectorAll("input").length > 1) break;
      const t = (p.innerText || "").trim();
      if (t && t.length < 60) return t;
    }
    return "";
  }

  function findEmailField(force) {
    const pw = loginPassword();
    if (!pw && !force) return null;
    let inputs = [...document.querySelectorAll('input:not([type]), input[type="email"], input[type="text"]')].filter(visible);
    // Only boxes that come before the password box (the sign-in form itself).
    if (pw) inputs = inputs.filter(i => i.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING);
    const hinted = inputs.find(i => {
      if (i.type === "email") return true;
      const attrs = [i.name, i.id, i.placeholder, i.autocomplete, i.getAttribute("aria-label"),
                     i.labels && i.labels[0] && i.labels[0].innerText, nearbyText(i)].join(" ");
      return EMAIL_HINT.test(attrs);
    });
    if (hinted) return hinted;
    // Fallback: the text box just before the password box.
    return pw && inputs.length ? inputs[inputs.length - 1] : null;
  }

  // ---------- Filling the field (works with React/Angular inputs) ----------
  function fillField(field, value) {
    field.focus();
    try { field.select(); } catch (_) {}
    let ok = false;
    try { ok = document.execCommand("insertText", false, value); } catch (_) {}
    if (!ok || field.value !== value) {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      setter.call(field, value);
      field.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    }
    field.dispatchEvent(new Event("change", { bubbles: true }));
    field.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Enter" }));
    field.dispatchEvent(new Event("blur"));
    field.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
  }

  function focusPassword() {
    const pw = [...document.querySelectorAll('input[type="password"]')].find(visible);
    if (pw) setTimeout(() => pw.focus(), 50);
  }

  // ---------- Small reopen button beside the field ----------
  function attachBadge(field) {
    if (field.dataset.nepBadge) { if (field.__nepPlace) field.__nepPlace(); return; }
    field.dataset.nepBadge = "1";
    const b = document.createElement("button");
    b.type = "button";
    b.title = "Choose a Nextiva email";
    b.textContent = "✉";
    Object.assign(b.style, {
      position: "absolute", zIndex: 2147483646, width: "26px", height: "26px",
      border: "none", borderRadius: "6px", background: "#005fec", color: "#fff",
      font: "15px/26px system-ui, sans-serif", cursor: "pointer", padding: "0",
      boxShadow: "0 1px 4px rgba(0,0,0,.25)"
    });
    const place = () => {
      if (!document.contains(field) || !visible(field) || !loginPassword()) { b.style.display = "none"; return; }
      const r = field.getBoundingClientRect();
      b.style.display = "block";
      b.style.left = `${window.scrollX + r.right - 30}px`;
      b.style.top = `${window.scrollY + r.top + (r.height - 26) / 2}px`;
    };
    b.addEventListener("mousedown", e => e.preventDefault());
    b.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); openPicker(field); });
    document.body.appendChild(b);
    field.__nepPlace = place;
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    setInterval(place, 800);
  }

  // ---------- Picker overlay ----------
  const CSS = `
    :host { all: initial; }
    .back { position: fixed; inset: 0; background: rgba(10,20,40,.55); display: flex;
      align-items: center; justify-content: center; z-index: 2147483647;
      font-family: "Segoe UI", system-ui, -apple-system, sans-serif; }
    .card { background: #fff; width: min(1280px, 96vw); max-height: 94vh; border-radius: 12px;
      box-shadow: 0 18px 50px rgba(0,0,0,.35); display: flex; flex-direction: column; overflow: hidden; }
    .head { background: #005fec; color: #fff; padding: 12px 18px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }
    .head h2 { margin: 0; font-size: 17px; font-weight: 600; }
    .head p { margin: 3px 0 0; font-size: 12.5px; opacity: .85; }
    .x { border: none; background: rgba(255,255,255,.15); color: #fff; width: 30px; height: 30px; border-radius: 7px;
      font: 18px/30px system-ui, sans-serif; cursor: pointer; padding: 0; flex: none; }
    .x:hover { background: rgba(255,255,255,.3); }
    input { box-sizing: border-box; width: 100%; padding: 9px 11px; font-size: 14px;
      border: 1px solid #c9d2e0; border-radius: 7px; outline: none; color: #1b2433; background: #fff; }
    input:focus { border-color: #005fec; box-shadow: 0 0 0 3px rgba(0,95,236,.15); }
    .list { overflow: visible; padding: 6px 16px 12px; flex: 1; display: flex; flex-wrap: wrap; column-gap: 16px; align-content: flex-start; }
    .group { margin-top: 8px; flex: 0 0 auto; }
    .group.wide { flex: 1 1 100%; }
    .gname { font-size: 11px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
      color: #005fec; padding: 4px 2px 5px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 6px; }
    .item { border: 1px solid #d5ddea; background: #f7f9fc; padding: 10px 8px; border-radius: 8px;
      cursor: pointer; font: 600 13.5px "Segoe UI", system-ui, sans-serif; color: #1b2433; text-align: center;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .item:hover { background: #005fec; border-color: #005fec; color: #fff; }
    .empty { color: #5a6578; font-size: 13px; padding: 18px 8px; text-align: center; }
    .foot { display: flex; justify-content: space-between; gap: 8px; padding: 12px 18px;
      border-top: 1px solid #e6eaf1; background: #f7f9fc; }
    .btn { border: 1px solid #c9d2e0; background: #fff; color: #1b2433; border-radius: 7px;
      padding: 8px 14px; font: 600 13px "Segoe UI", system-ui, sans-serif; cursor: pointer; }
    .btn:hover { background: #eef2f8; }
    .btn.primary { background: #005fec; border-color: #005fec; color: #fff; }
    .btn.primary:hover { background: #004fc7; }
    .form { padding: 12px 18px; display: grid; gap: 10px; }
    label { font-size: 12px; font-weight: 600; color: #3a4558; display: grid; gap: 4px; }
    .err { color: #c62828; font-size: 12.5px; min-height: 16px; }
    .head.red { background: #c62828; }
    .gname.red { color: #c62828; }
    .item.del { border-color: #f1c4c4; background: #fff7f7; }
    .item.del:hover, .item.del.sel { background: #c62828; border-color: #c62828; color: #fff; }
    .btn.danger { background: #c62828; border-color: #c62828; color: #fff; }
    .btn.danger:hover { background: #a91f1f; }
    .btn.danger:disabled { opacity: .45; cursor: default; }
    .deltext { align-self: center; font-size: 13px; color: #1b2433; }
    .foot { align-items: center; }
  `;

  function el(tag, attrs = {}, ...kids) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === "class") n.className = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v);
    }
    for (const k of kids) n.append(k);
    return n;
  }

  function closePicker(refocus = true) {
    if (host) { host.remove(); host = null; }
    if (refocus && activeField && document.contains(activeField)) activeField.focus();
  }

  async function openPicker(field) {
    activeField = field;
    closePicker(false);
    host = el("div");
    const root = host.attachShadow({ mode: "closed" });
    root.append(el("style", {}, CSS));
    const card = el("div", { class: "card", role: "dialog", "aria-label": "Choose a Nextiva email" });
    const back = el("div", { class: "back" }, card);
    back.addEventListener("mousedown", e => { if (e.target === back) closePicker(); });
    root.append(back);
    document.documentElement.appendChild(host);
    showList(card);
  }

  async function showList(card) {
    const list = await nepLoad();
    card.replaceChildren();
    const listBox = el("div", { class: "list" });
    const groups = nepGroup(list, "");
    if (!groups.length) listBox.append(el("div", { class: "empty" }, "No emails yet. Use “Add new email” below."));
    for (const g of groups) {
      const wide = g.items.length > 3;
      const grid = el("div", { class: "grid" });
      grid.style.gridTemplateColumns = wide ? "repeat(auto-fill, 140px)" : `repeat(${g.items.length}, 140px)`;
      for (const it of g.items) {
        grid.append(el("button", { class: "item", type: "button", title: it.email, onclick: () => choose(it.email) },
          it.tenant || it.partner));
      }
      listBox.append(el("div", { class: wide ? "group wide" : "group" }, el("div", { class: "gname" }, g.partner), grid));
    }

    card.onkeydown = e => { if (e.key === "Escape") { e.preventDefault(); closePicker(); } };

    card.append(
      el("div", { class: "head" },
        el("div", {}, el("h2", {}, "Choose your Nextiva login"),
          el("p", {}, "One click fills the Email field.")),
        el("button", { class: "x", type: "button", title: "Close", onclick: () => closePicker() }, "✕")),
      listBox,
      el("div", { class: "foot" },
        el("button", { class: "btn", type: "button", onclick: () => showAdd(card) }, "+ Add new email"),
        el("span", {},
          el("button", { class: "btn", type: "button", onclick: () => showDelete(card) }, "Delete email"), " ",
          el("button", { class: "btn", type: "button", onclick: () => closePicker() }, "Cancel")))
    );
    setTimeout(() => card.querySelector(".item")?.focus(), 0);
  }

  async function showDelete(card) {
    const list = await nepLoad();
    let selected = null;
    card.replaceChildren();
    const listBox = el("div", { class: "list" });
    const text = el("span", { class: "deltext" }, "Click the email you want to delete.");
    const confirm = el("button", { class: "btn danger", type: "button", disabled: "" }, "Delete");
    for (const g of nepGroup(list, "")) {
      const wide = g.items.length > 3;
      const grid = el("div", { class: "grid" });
      grid.style.gridTemplateColumns = wide ? "repeat(auto-fill, 140px)" : `repeat(${g.items.length}, 140px)`;
      for (const it of g.items) {
        const b = el("button", { class: "item del", type: "button", title: it.email }, it.tenant || it.partner);
        b.onclick = () => {
          listBox.querySelectorAll(".item.sel").forEach(x => x.classList.remove("sel"));
          b.classList.add("sel");
          selected = it;
          text.textContent = `Delete ${it.tenant || it.partner} (${it.email})?`;
          confirm.disabled = false;
        };
        grid.append(b);
      }
      listBox.append(el("div", { class: wide ? "group wide" : "group" }, el("div", { class: "gname red" }, g.partner), grid));
    }
    confirm.onclick = async () => {
      if (!selected) return;
      await nepRemove(selected.email);
      showList(card);
    };
    card.onkeydown = e => { if (e.key === "Escape") { e.preventDefault(); showList(card); } };
    card.append(
      el("div", { class: "head red" },
        el("div", {}, el("h2", {}, "Delete an email"),
          el("p", {}, "Choose one, then click Delete. Nothing is removed until you confirm."))),
      listBox,
      el("div", { class: "foot" }, text,
        el("span", {},
          el("button", { class: "btn", type: "button", onclick: () => showList(card) }, "Cancel"), " ",
          confirm))
    );
  }

  async function showAdd(card) {
    const list = await nepLoad();
    const partners = [...new Set(list.map(e => e.partner))].sort();
    card.replaceChildren();
    const dl = el("datalist", { id: "nep-partners" }, ...partners.map(p => el("option", { value: p })));
    const partner = el("input", { type: "text", list: "nep-partners", placeholder: "e.g. Partner name" });
    const tenant = el("input", { type: "text", placeholder: "e.g. Tenant name" });
    const email = el("input", { type: "email", placeholder: "name@nextiva.com" });
    const err = el("div", { class: "err" });

    const save = async (useNow) => {
      err.textContent = "";
      if (!partner.value.trim()) return (err.textContent = "Enter a partner.");
      if (!nepValidEmail(email.value)) return (err.textContent = "Enter a valid email address.");
      try {
        await nepAdd({ partner: partner.value, tenant: tenant.value, email: email.value });
      } catch (e) { return (err.textContent = e.message); }
      if (useNow) choose(email.value.trim()); else showList(card);
    };

    card.onkeydown = e => { if (e.key === "Escape") { e.preventDefault(); showList(card); } };
    [partner, tenant, email].forEach(i => i.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); save(true); } }));

    card.append(
      el("div", { class: "head" }, el("h2", {}, "Add a new email"),
        el("p", {}, "Saved in this browser and shown in the list from now on.")),
      el("div", { class: "form" }, dl,
        el("label", {}, "Partner", partner),
        el("label", {}, "Tenant", tenant),
        el("label", {}, "Email", email),
        err),
      el("div", { class: "foot" },
        el("button", { class: "btn", type: "button", onclick: () => showList(card) }, "Back"),
        el("span", {},
          el("button", { class: "btn", type: "button", onclick: () => save(false) }, "Save"), " ",
          el("button", { class: "btn primary", type: "button", onclick: () => save(true) }, "Save & use")))
    );
    setTimeout(() => partner.focus(), 0);
  }

  function choose(email) {
    const f = activeField;
    closePicker(false);
    if (f && document.contains(f)) {
      fillField(f, email);
      focusPassword();
    }
  }

  // ---------- Watch the page (login pages often render late or change steps) ----------
  function scan() {
    const f = findEmailField();
    if (!f) {
      // Left the sign-in screen (e.g. after logging in): close the picker and hide the badge.
      if (host) closePicker(false);
      document.querySelectorAll('button[title="Choose a Nextiva email"]').forEach(b => { b.style.display = "none"; });
      return;
    }
    attachBadge(f);
    if (!handled.has(f) && !host) {
      handled.add(f);
      openPicker(f);
    }
  }

  // ---------- Toolbar popup asks this page to fill the email ----------
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (!msg || msg.type !== "nep-fill") return;
    const f = findEmailField();
    if (!f) return;                 // let another frame answer
    closePicker(false);
    fillField(f, msg.email);
    focusPassword();
    reply({ ok: true });
  });

  let t = null;
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(scan, 250); })
    .observe(document.documentElement, { childList: true, subtree: true });
  scan();
})();
