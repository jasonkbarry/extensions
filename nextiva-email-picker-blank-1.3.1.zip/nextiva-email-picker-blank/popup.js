const $ = id => document.getElementById(id);
let mode = "pick";       // "pick" | "delete" | "add"
let selected = null;     // entry chosen for deletion

function setMode(m) {
  mode = m;
  selected = null;
  document.body.classList.toggle("del", m === "delete");
  $("barMain").classList.toggle("hidden", m !== "pick");
  $("barDel").classList.toggle("hidden", m !== "delete");
  $("barAdd").classList.toggle("hidden", m !== "add");
  $("msg").textContent = "";
  $("err").textContent = "";
  $("delConfirm").disabled = true;
  $("delText").textContent = "Click the email you want to delete.";
  if (m === "delete") {
    $("title").textContent = "Delete an email";
    $("sub").textContent = "Choose one, then click Delete. Nothing is removed until you confirm.";
  } else if (m === "add") {
    $("title").textContent = "Add an email";
    $("sub").textContent = "It will show in the list from now on.";
    setTimeout(() => $("partner").focus(), 0);
  } else {
    $("title").textContent = "Choose your Nextiva login";
    $("sub").textContent = "Click an email to fill the Email field.";
  }
  render();
}

function chip(it) {
  const b = document.createElement("button");
  b.className = "item"; b.type = "button";
  b.textContent = it.tenant || it.partner;
  b.title = it.email;
  if (mode === "delete" && selected && selected.email === it.email) b.classList.add("sel");
  b.onclick = () => {
    if (mode === "delete") {
      selected = it;
      $("delText").textContent = `Delete ${it.tenant || it.partner} (${it.email})?`;
      $("delConfirm").disabled = false;
      render();
    } else {
      fill(it.email);
    }
  };
  return b;
}

async function render() {
  const list = await nepLoad();
  const box = $("list");
  box.replaceChildren();
  const groups = nepGroup(list, "");
  if (!groups.length) {
    const d = document.createElement("div"); d.className = "empty";
    d.textContent = "No emails yet. Click + Add email to add one.";
    box.append(d);
  }
  for (const g of groups) {
    const grp = document.createElement("div");
    grp.className = g.items.length > 3 ? "group wide" : "group";
    const h = document.createElement("div"); h.className = "gname"; h.textContent = g.partner;
    const chips = document.createElement("div"); chips.className = "chips";
    g.items.forEach(it => chips.append(chip(it)));
    grp.append(h, chips);
    box.append(grp);
  }
  $("partners").replaceChildren(...[...new Set(list.map(e => e.partner))].sort().map(p => {
    const o = document.createElement("option"); o.value = p; return o;
  }));
}

async function sendFill(tabId, email) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: "nep-fill", email });
    return !!(r && r.ok);
  } catch (_) { return false; }
}

async function fill(email) {
  $("msg").textContent = "";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  let ok = await sendFill(tab.id, email);
  if (!ok) {
    // Page was open before the extension loaded: inject the page script, then try again.
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        files: ["defaults.js", "store.js", "content.js"]
      });
      ok = await sendFill(tab.id, email);
    } catch (_) {}
  }
  if (ok) window.close();
  else $("msg").textContent = "Couldn't find an Email field on this page. This only works on the Nextiva sign-in screen.";
}

$("delOpen").onclick = () => setMode("delete");
$("delCancel").onclick = () => setMode("pick");
$("delConfirm").onclick = async () => {
  if (!selected) return;
  await nepRemove(selected.email);
  setMode("pick");
};

$("addOpen").onclick = () => setMode("add");
$("addCancel").onclick = () => setMode("pick");
async function add() {
  $("err").textContent = "";
  const partner = $("partner").value, tenant = $("tenant").value, email = $("email").value;
  if (!partner.trim()) return ($("err").textContent = "Enter a partner.");
  if (!nepValidEmail(email)) return ($("err").textContent = "Enter a valid email address.");
  try { await nepAdd({ partner, tenant, email }); }
  catch (e) { return ($("err").textContent = e.message); }
  $("partner").value = ""; $("tenant").value = ""; $("email").value = "";
  setMode("pick");
}
$("addBtn").onclick = add;
["partner", "tenant", "email"].forEach(id => $(id).addEventListener("keydown", e => { if (e.key === "Enter") add(); }));

document.addEventListener("keydown", e => {
  if (e.key === "Escape" && mode !== "pick") { e.preventDefault(); setMode("pick"); }
});

setMode("pick");
