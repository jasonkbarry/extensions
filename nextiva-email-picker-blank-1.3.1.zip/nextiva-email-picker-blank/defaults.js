// Starting list, loaded the first time the extension runs. Empty: each user adds their own emails.
const NEP_DEFAULT_EMAILS = [];
