# Journeys Time Entry

A Chrome extension for entering your weekly time in **Nextiva Journeys** (onboarding.nextiva.com) from a single timesheet-style grid. It can also copy every billable entry into the **Burn Down Record** Google Sheet.

- One row per activity (Kanban card) or admin category, one column per day (Mon–Sun).
- It loads your existing entries for the week. **Submit** only sends what changed: new cells are created, changed hours are updated, and cleared cells are deleted after you confirm.
- **Project** mode logs time to the cards you pick on each customer's post-onboarding board. The category is always Technical, and entries are Billable by default, switchable per row.
- **Admin** mode shows your pinned Timesheet categories (FTO / Holiday, Internal meeting, Admin / email, and so on). These are always non-billable.
- You can go back to earlier weeks. New entries can't be created on future dates.
- A reminder notification appears every Wednesday at 4 PM, because time is due at 7 PM.

The extension uses your own signed-in Journeys session in Chrome. There are no passwords or API keys to set up.

---

## 1. Install the extension

1. Download the zip and extract it (right-click → **Extract All**). Move the `journeys-time-entry` folder somewhere permanent, such as Documents. Chrome loads it from there.
2. Go to `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the `journeys-time-entry` folder.
4. Pin **Journeys Time Entry** from the puzzle-piece menu.
5. Make sure you're signed in to https://onboarding.nextiva.com in Chrome.

## 2. Add your customers (boards)

1. In Journeys, open a customer's **post-onboarding board** and copy the URL from the address bar. It looks like `…/employee/pm/accounts/<id>/projects/<id>/post-onboarding`.
2. In the extension, click **⚙**, paste the URL under **Add a board**, and click **Add**. The customer name is filled in automatically, and you can rename it.
3. Click **Activities: 0 selected ▸** under the customer and tick the cards you log time to. You can pick cards from any column (New, Scope, Present, Test, and so on). **Nothing is ticked by default.**
4. Repeat for each customer.

Admin categories come from the pins on your Journeys **Timesheet** page. To change them, pin or unpin categories there, then click ↻ in the extension.

## 3. Enter time

1. Choose **Project** (and a customer) or **Admin**.
2. Type hours in the grid. Enter moves down a column. The totals per row, per day and for the week update as you type.
3. Optional: add a comment per row. It applies to the **new** entries in that row. Click **BILLABLE** to switch a row's new entries to non-billable.
4. Click **Submit**. The button shows what will be sent, for example "Submit: 2 new · 1 change · 1 delete."

How the grid shows each cell:

| Look | Meaning |
|---|---|
| Green | Already in Journeys. Hover over it to see the comment and billing. |
| Blue | New or changed, and will be sent on Submit |
| Red "del" | You cleared an existing entry. It will be **deleted** (you'll be asked to confirm first). |
| Green with a number badge | More than one entry that day. Read-only; edit these in Journeys. |
| "(not selected)" row | A card you didn't tick that has time this week, shown so the totals are right |

Changing an existing cell only changes its **hours**. Its comment and billing stay as they are. Anything you've typed but not submitted is kept if you close the popup. **Discard changes** throws it away.

---

## 4. Optional: Burn Down Record sheet

If you also track billable hours in the Burn Down Record sheet, the extension can add a row there for every **billable** entry it creates. Non-billable and admin time are never written to the sheet.

It writes to the **first row in your tab whose Customer Name (column B) is empty**, filling in these columns:

| Column | Value |
|---|---|
| B | Customer name (as set in ⚙ for that board) |
| C | Customer account number |
| D | Date of the entry |
| E | Hours |
| G | CSP level (Standard / Advanced / Signature - TAM) |
| H | Allotted hours |
| I | Bucket of hours |

Columns A (Burn Down ID), F (Kanban), J (Total Hours, a formula) and K–M are left alone.

The extension writes to the sheet through a small **Google Apps Script web app** that you create under your own Google account (the script file is `apps-script/BurnDown.gs`).

### 4a. Create the Apps Script web app (one time, about 3 minutes)

1. Go to https://script.google.com, signed in with the Google account that can **edit** the Burn Down Record. Click **New project**.
2. Press **Ctrl+A** and **Delete** to remove the starter `function myFunction() { }` code. The editor must be completely empty.
3. Open `apps-script/BurnDown.gs` from the extension folder, copy **all** of it, paste it into the editor, and save (Ctrl+S).
4. Near the top of the script, set **`SHEET_ID`** to the Burn Down Record's ID. That's the long code in the sheet's URL:
   `https://docs.google.com/spreadsheets/d/`**`THIS_PART`**`/edit…`
   Save again.
5. Click **Deploy → New deployment**. Click the gear icon next to "Select type" and choose **Web app**:
   - **Execute as:** Me
   - **Who has access:** Only myself
6. Click **Deploy → Authorize access**, then choose the same Google account. If you see "Google hasn't verified this app," click **Advanced → Go to (project) (unsafe)**. That's expected for your own script. Then click **Allow**.
7. Copy the **Web app URL** (it ends in `/exec`). If you closed that screen, it's under **Deploy → Manage deployments**.
8. Open that URL in Chrome. You should see something like `{"ok":true,"tab":"…","nextRow":170}`.

### 4b. Connect the extension

1. Click **⚙**, go to **Burn Down sheet**, and paste the `/exec` URL into **Web app URL**.
2. Enter **Tab name**. This is your tab in the sheet, exactly as it's spelled there, for example `Jane Smith`.
3. Click **Save & test**. It should say *Connected to "Jane Smith" — next empty row is …*
4. For **each customer** in ⚙, fill in the sheet fields: **Sheet customer name** (as it appears in the sheet), **Account #**, **CSP level**, **Allotted** and **Bucket**. Total is shown for reference only; the sheet calculates its own. Billable time can't be submitted for a customer until its customer name, account number and CSP level are filled in.

### How the sheet sync behaves

- After a submit, the message lists the Burn Down IDs that were added (for example `BDJB-0000169`).
- If the sheet can't be reached, the Journeys entries are still saved. The sheet rows are kept, and an amber bar shows **N rows waiting — Retry now**.
- **Changing or deleting** an existing billable entry doesn't change the sheet. The extension reminds you to update those rows by hand.

### Changing the script later

If you edit `BurnDown.gs`, for example to change columns or add a token:

1. Paste the new code into your Apps Script project and save.
2. Go to **Deploy → Manage deployments**, click the pencil ✏ on your deployment, and set **Version: New version**. Click **Deploy**.
   This keeps the **same URL**, so the extension doesn't need changing. Using **New deployment** instead creates a new URL, which you'd have to paste into ⚙ again.

**Optional token:** set `TOKEN = 'some-long-random-text'` in the script, redeploy as above, and enter the same text in the extension's **Token** field. Requests without that token are refused.

### Troubleshooting

| Message | Fix |
|---|---|
| "Google sign-in needed for the Burn Down web app" | Open the `/exec` URL in Chrome once. If you're signed in to several Google accounts, the web app uses your **default** (first) account, so sign in with the owner account first, or redeploy under that account. |
| "Tab not found" | The Tab name in ⚙ must match the sheet tab exactly, including spaces. |
| "Fill in the Burn Down info for …" | Complete that customer's sheet fields in ⚙. |
| "Unknown request: …" after an update | Click the reload arrow on the extension in `chrome://extensions`. |
| "Not signed in to Journeys" | Sign in at onboarding.nextiva.com, then try again. |

---

## Updating the extension

Download the new zip, extract it, and copy its files over your existing `journeys-time-entry` folder. **Keep the folder name** so Chrome keeps your boards and settings. Then click the reload arrow on the extension in `chrome://extensions`. The `VERSION x.y.txt` file shows which version is in the folder.

## Privacy

Everything you configure (boards, sheet fields, the web app URL, unsent drafts) is stored only in your own Chrome profile. The extension talks only to `onboarding.nextiva.com` and to your own Apps Script web app.
