const DEFAULTS = {
  rowSelector: [
    'tr.selected',
    'tr.active',
    'tr.is-selected',
    'tr.highlighted',
    'tr[aria-selected="true"]',
    '[role="row"][aria-selected="true"]',
    '.row.selected',
    '.row.active',
    '.k-state-selected',
    '.ag-row-selected',
    '.rt-tr.selected',
    '.MuiDataGrid-row.Mui-selected'
  ].join(', '),
  mode: 'index',
  columnIndex: 0,
  columnHeader: '',
  cellSelector: '',
  attrName: 'data-id'
};

const $ = (id) => document.getElementById(id);

function showFields(mode) {
  document.querySelectorAll('.field').forEach((f) => {
    f.classList.toggle('show', f.dataset.for === mode);
  });
}

async function load() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  $('rowSelector').value = s.rowSelector;
  $('mode').value = s.mode;
  $('columnIndex').value = s.columnIndex;
  $('columnHeader').value = s.columnHeader;
  $('cellSelector').value = s.cellSelector;
  $('attrName').value = s.attrName;
  showFields(s.mode);
}

$('mode').addEventListener('change', (e) => showFields(e.target.value));

$('save').addEventListener('click', async () => {
  const data = {
    rowSelector: $('rowSelector').value.trim() || DEFAULTS.rowSelector,
    mode: $('mode').value,
    columnIndex: parseInt($('columnIndex').value, 10) || 0,
    columnHeader: $('columnHeader').value.trim(),
    cellSelector: $('cellSelector').value.trim(),
    attrName: $('attrName').value.trim() || 'data-id'
  };
  await chrome.storage.sync.set(data);
  const st = $('status');
  st.textContent = 'Saved.';
  setTimeout(() => (st.textContent = ''), 1500);
});

load();
