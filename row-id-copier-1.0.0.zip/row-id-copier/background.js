// Row ID Copier — service worker.
// Triggered by the toolbar icon click and by the keyboard shortcut.
// Reads user settings, injects a grabber into the active tab, copies the value,
// and gives visual feedback (badge + on-page toast).

const DEFAULTS = {
  // CSS selectors that identify the "selected" row. First match wins.
  rowSelector: [
    'tr.selected',
    'tr.active',
    'tr.is-selected',
    'tr.highlighted',
    'tr[aria-selected="true"]',
    '[role="row"][aria-selected="true"]',
    '.row.selected',
    '.row.active',
    '.k-state-selected',           // Kendo UI
    '.ag-row-selected',            // ag-Grid
    '.rt-tr.selected',             // react-table
    '.MuiDataGrid-row.Mui-selected' // MUI DataGrid
  ].join(', '),
  // How to pick the identifier cell inside the selected row:
  //   'index'   -> use columnIndex (0-based)
  //   'header'  -> find the column whose header text matches columnHeader
  //   'cell'    -> query a custom cellSelector within the row
  //   'attr'    -> read an attribute (attrName) off the row element
  mode: 'index',
  columnIndex: 0,
  columnHeader: '',
  cellSelector: '',
  attrName: 'data-id'
};

async function getSettings() {
  const stored = await chrome.storage.sync.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

async function run(tab) {
  if (!tab || !tab.id) return;
  const settings = await getSettings();
  let result;
  try {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: grabAndCopy,
      args: [settings]
    });
    result = injection && injection.result;
  } catch (e) {
    result = { ok: false, message: 'Cannot run on this page (' + e.message + ')' };
  }

  const ok = result && result.ok;
  await chrome.action.setBadgeBackgroundColor({
    tabId: tab.id,
    color: ok ? '#1a7f37' : '#cf222e'
  });
  await chrome.action.setBadgeText({ tabId: tab.id, text: ok ? '\u2713' : '!' });
  setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: '' }), 1500);
}

// This function is serialized and executed inside the page.
function grabAndCopy(settings) {
  function findRow() {
    const list = document.querySelectorAll(settings.rowSelector);
    if (list.length) return list[list.length - 1]; // most-recently selected tends to be last
    return null;
  }

  function cellsOf(row) {
    let cells = row.querySelectorAll(':scope > td, :scope > th, :scope > [role="cell"], :scope > [role="gridcell"]');
    if (!cells.length) {
      cells = row.querySelectorAll('td, th, [role="cell"], [role="gridcell"]');
    }
    if (!cells.length) {
      // Angular / div-based grids (e.g. NCC): .inner-row > .cell
      cells = row.querySelectorAll(':scope > .inner-row > .cell, :scope > .cell');
    }
    if (!cells.length) {
      cells = row.querySelectorAll('.cell');
    }
    return Array.from(cells);
  }

  function cellText(cell) {
    if (!cell) return null;
    // Prefer an inner .content element if present (Angular grids), else full text.
    const content = cell.querySelector(':scope > .content, .content');
    return ((content || cell).textContent || '').trim();
  }

  function headerIndex(row, headerText) {
    const table = row.closest('table, [role="grid"], [role="table"]');
    if (!table) return -1;
    const heads = table.querySelectorAll('thead th, thead td, [role="columnheader"], th');
    const want = headerText.trim().toLowerCase();
    let i = 0;
    for (const h of heads) {
      if ((h.textContent || '').trim().toLowerCase() === want) return i;
      i++;
    }
    return -1;
  }

  function extract(row) {
    switch (settings.mode) {
      case 'attr': {
        const v = row.getAttribute(settings.attrName);
        return v == null ? null : v.trim();
      }
      case 'cell': {
        const el = settings.cellSelector ? row.querySelector(settings.cellSelector) : null;
        return el ? (el.textContent || '').trim() : null;
      }
      case 'header': {
        const idx = headerIndex(row, settings.columnHeader || '');
        if (idx < 0) return null;
        const cells = cellsOf(row);
        return cells[idx] ? cellText(cells[idx]) : null;
      }
      case 'index':
      default: {
        const cells = cellsOf(row);
        const idx = Math.max(0, parseInt(settings.columnIndex, 10) || 0);
        return cells[idx] ? cellText(cells[idx]) : null;
      }
    }
  }

  function copyText(text) {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.top = '-1000px';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      if (ok) return true;
    } catch (e) { /* fall through */ }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => {});
      return true;
    }
    return false;
  }

  function toast(msg, good) {
    const el = document.createElement('div');
    el.textContent = msg;
    el.style.cssText = [
      'position:fixed', 'z-index:2147483647', 'right:16px', 'bottom:16px',
      'padding:10px 14px', 'border-radius:6px', 'font:13px/1.3 system-ui,sans-serif',
      'color:#fff', 'box-shadow:0 2px 8px rgba(0,0,0,.3)',
      'background:' + (good ? '#1a7f37' : '#cf222e'),
      'max-width:360px', 'word-break:break-all'
    ].join(';');
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2200);
  }

  const row = findRow();
  if (!row) {
    toast('No selected row found on this page.', false);
    return { ok: false, message: 'no row' };
  }
  const value = extract(row);
  if (value == null || value === '') {
    const html = (row.outerHTML || '').slice(0, 8000);
    copyText(html);
    toast('No value at target column. Row HTML copied to clipboard \u2014 paste it to configure.', false);
    return { ok: false, message: 'empty value', debugHtml: html };
  }
  const copied = copyText(value);
  toast(copied ? ('Copied: ' + value) : ('Could not copy: ' + value), copied);
  return { ok: copied, value: value };
}

chrome.action.onClicked.addListener((tab) => run(tab));

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'copy-selected-id') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  run(tab);
});
