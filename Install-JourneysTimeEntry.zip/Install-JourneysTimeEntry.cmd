@echo off
title Journeys Time Entry installer
rem Installs or updates Journeys Time Entry. Double-click to run.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$x='journeys-time-entry'; irm https://jasonkbarry.github.io/extensions/install.txt | iex"
