(() => {
  // ===========================================================================
  // CALLBACK DISPOSITION GUARD
  // ===========================================================================

  // Call we've already warned about (keyed by phone number + call start time). After the warning,
  // the agent can use the disposition box normally for that call.
  let warnedFor = null;

  const PHONE_RE = /^\+?1?\d{10}$/;
  const STATUS_RE = /outbound call\s*\/\s*in review/i;

  function isVisible(el) {
    return el.offsetParent !== null;
  }

  function inReview() {
    for (const el of document.querySelectorAll('div.content, div.others')) {
      if (isVisible(el) && STATUS_RE.test(el.textContent)) return true;
    }
    return false;
  }

  function findPhoneEl() {
    for (const el of document.querySelectorAll('body *')) {
      if (el.children.length === 0 && isVisible(el) && PHONE_RE.test(el.textContent.trim())) return el;
    }
    return null;
  }

  // Unique key for the current call: phone number + the call's start time shown in the
  // work-item header (e.g. "11/06/2026 01:10:01"). Phone alone isn't enough because the
  // same customer can be called back more than once.
  const TIME_RE = /\d{1,2}\/\d{1,2}\/\d{4}\s+\d{1,2}:\d{2}(:\d{2})?/;

  function callKey() {
    const header = document.querySelector('ln-workitem-panel .ln-header');
    const phoneEl = (header && header.querySelector('.left-section')) || findPhoneEl();
    const phone = phoneEl ? phoneEl.textContent.trim() : '';
    let started = '';
    if (header) {
      for (const el of header.querySelectorAll('div.others')) {
        const m = el.textContent.match(TIME_RE);
        if (m) { started = m[0]; break; }
      }
      if (!started) {
        const m = header.textContent.match(TIME_RE);
        if (m) started = m[0];
      }
    }
    if (!phone && !started) return null; // can't identify the call: always warn
    return phone + '|' + started;
  }

  function closeModal() {
    document.getElementById('dg-overlay')?.remove();
  }

  function showModal() {
    if (document.getElementById('dg-overlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'dg-overlay';
    overlay.innerHTML = `
      <div id="dg-box" role="alertdialog" aria-modal="true">
        <img id="dg-logo" alt="Nextiva">
        <div id="dg-title">⚠️ This is a customer callback</div>
        <p>Please call the customer back before choosing a disposition.</p>
        <p id="dg-where">📞 Click the customer's <strong>phone number at the top of the screen</strong>, just above <strong>"Outbound Call / In review"</strong>.</p>
        <p id="dg-note">To choose a disposition without calling, close this and try again.</p>
        <button id="dg-close">OK</button>
      </div>`;
    const style = document.createElement('style');
    style.textContent = `
      #dg-overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif}
      #dg-box{background:#fff;color:#222;border-radius:16px;padding:48px 56px;width:min(900px,90vw);max-height:90vh;overflow:auto;box-sizing:border-box;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.5);border-top:12px solid #e53935}
      #dg-logo{display:block;height:72px;margin:0 auto 20px}
      #dg-title{font-size:42px;font-weight:800;line-height:1.2;margin-bottom:20px}
      #dg-box p{margin:18px 0 24px;font-size:28px;line-height:1.4}
      #dg-where{background:#fff8e1;border:2px solid #ffe082;border-radius:12px;padding:24px 28px;font-size:30px!important}
      #dg-note{margin:0 0 28px!important;font-size:20px!important;color:#666}
      #dg-close{margin-top:8px;padding:16px 64px;border-radius:10px;cursor:pointer;font-size:26px;font-weight:700;background:#2e7d32;color:#fff;border:2px solid #2e7d32}`;
    overlay.appendChild(style);
    document.body.appendChild(overlay);

    const logo = overlay.querySelector('#dg-logo');
    logo.onerror = () => logo.remove();
    logo.src = 'https://nextiva.thrio.io/lioncc/assets/images/nextiva-small-logo-dark.svg?v=3';

    overlay.querySelector('#dg-close').onclick = closeModal;
    overlay.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' || e.key === 'Enter') { e.preventDefault(); closeModal(); }
    });
    overlay.querySelector('#dg-close').focus();
  }

  // Disposition box itself, plus its dropdown list of options.
  function isDispositionTarget(t) {
    return t instanceof Element && (t.closest('ln-disposition') || t.closest('.p-autocomplete-panel'));
  }

  function guard(e) {
    if (!isDispositionTarget(e.target)) return;
    if (!inReview()) return;

    const key = callKey();
    if (key && warnedFor === key) return; // already warned for this call: allow normally

    e.preventDefault();
    e.stopImmediatePropagation();
    if (e.type === 'focusin') e.target.blur();

    showModal();
    warnedFor = key; // next attempt on this call goes through
  }

  // The popup covers the screen, so the rest of the same physical click lands on it.
  document.addEventListener('mousedown', guard, true);
  document.addEventListener('click', guard, true);
  document.addEventListener('focusin', guard, true);
  document.addEventListener('keydown', guard, true);
})();
