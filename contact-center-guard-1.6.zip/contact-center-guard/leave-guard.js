(() => {
  // ===========================================================================
  // LEAVE GUARD
  // BACK is always blocked:
  //   - Alt+Left / Cmd+[ are cancelled, and the browser Back button is undone.
  //   - Shows the Back popup.
  // REFRESH is blocked once, then allowed on the next try:
  //   - Ctrl+R / Ctrl+Shift+R / F5 / Cmd+R are cancelled and show the Refresh
  //     popup. Trying again within REFRESH_RETRY_MS reloads the page.
  // Closing the tab, typing a new URL, bookmarks and the toolbar Reload
  // button are not blocked.
  // ===========================================================================
  const POPUPS = {
    back: {
      title: '⛔ The Back button is disabled',
      msg: 'Using the Back button will close Nextiva Contact Center and end your call.',
      note: '',
    },
    refresh: {
      title: '⚠️ Refreshing will end your call',
      msg: 'Refreshing the page will close Nextiva Contact Center and end your call.',
      note: 'If you need to refresh anyway, close this and refresh again.',
    },
  };
  const REFRESH_RETRY_MS = 60 * 1000; // second refresh within 1 minute goes through
  const NEXTIVA_ORIGIN = 'https://nextiva.thrio.io';
  const LOGO_URL = 'https://nextiva.thrio.io/lioncc/assets/images/nextiva-small-logo-dark.svg?v=3';
  const IS_TOP = window === window.top;

  let handleAttempt = () => {};

  function keyAction(e) {
    const k = e.key;
    if (k === 'F5' || k === 'BrowserRefresh') return 'refresh';
    if ((e.ctrlKey || e.metaKey) && !e.altKey && (k === 'r' || k === 'R')) return 'refresh';
    if (k === 'BrowserBack') return 'back';
    if (e.altKey && !e.ctrlKey && !e.metaKey && k === 'ArrowLeft') return 'back';
    if (e.metaKey && k === '[') return 'back'; // Mac back shortcut
    return null;
  }

  // Runs in every frame: the shortcut may be pressed while focus is inside an iframe.
  // The top frame always makes the decision.
  window.addEventListener('keydown', (e) => {
    const action = keyAction(e);
    if (!action) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (IS_TOP) handleAttempt(action);
    else window.top.postMessage({ ccGuard: action }, NEXTIVA_ORIGIN);
  }, true);

  if (!IS_TOP) return;

  let refreshWarnedAt = 0;   // when the Refresh popup was last shown

  // Shortcuts pressed inside iframes.
  window.addEventListener('message', (e) => {
    if (e.origin !== NEXTIVA_ORIGIN || !e.data) return;
    if (e.data.ccGuard === 'refresh' || e.data.ccGuard === 'back') handleAttempt(e.data.ccGuard);
  });

  handleAttempt = (action) => {
    if (action === 'refresh') {
      if (refreshWarnedAt && Date.now() - refreshWarnedAt < REFRESH_RETRY_MS) {
        // Second try: let it through.
        refreshWarnedAt = 0;
        location.reload();
        return;
      }
      refreshWarnedAt = Date.now();
    }
    showPopup(action);
  };

  // Back button. Nextiva's app adds its own history steps and reacts to Back
  // itself, so we catch every Back before the app sees it (capture listener +
  // stopImmediatePropagation) and immediately go forward again.
  // One extra same-URL step, added on the agent's first click, makes sure
  // Back always stays inside this page instead of leaving it.
  let armed = false;
  let returning = 0; // popstate events caused by our own history.go(1)
  function arm() {
    if (armed) return;
    history.pushState(Object.assign({}, history.state, { ccGuardTrap: true }), '', location.href);
    armed = true;
  }
  window.addEventListener('pointerdown', arm, true);
  window.addEventListener('keydown', arm, true);

  window.addEventListener('popstate', (e) => {
    if (!armed) return;
    e.stopImmediatePropagation(); // the app never sees Back
    if (returning > 0) { returning--; return; }
    returning++;
    history.go(1); // undo the Back
    handleAttempt('back');
  }, true);

  function showPopup(action) {
    document.getElementById('ccl-overlay')?.remove();
    const p = POPUPS[action];
    const overlay = document.createElement('div');
    overlay.id = 'ccl-overlay';
    overlay.innerHTML = `
      <div id="ccl-box" role="alertdialog" aria-modal="true">
        <img id="ccl-logo" alt="Nextiva">
        <div id="ccl-title"></div>
        <p id="ccl-msg"></p>
        <p id="ccl-note"></p>
        <button id="ccl-ok">OK</button>
      </div>`;
    const logo = overlay.querySelector('#ccl-logo');
    logo.onerror = () => logo.remove();
    logo.src = LOGO_URL;
    overlay.querySelector('#ccl-title').textContent = p.title;
    overlay.querySelector('#ccl-msg').textContent = p.msg;
    const note = overlay.querySelector('#ccl-note');
    if (p.note) note.textContent = p.note; else note.remove();
    const style = document.createElement('style');
    style.textContent = `
      #ccl-overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif}
      #ccl-box{background:#fff;color:#222;border-radius:16px;padding:48px 56px;width:min(900px,90vw);max-height:90vh;overflow:auto;box-sizing:border-box;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.5);border-top:12px solid #e53935}
      #ccl-logo{display:block;height:72px;margin:0 auto 20px}
      #ccl-title{font-size:42px;font-weight:800;line-height:1.2;margin-bottom:20px}
      #ccl-msg{margin:18px 0 24px;font-size:28px;line-height:1.4}
      #ccl-note{margin:0 0 28px;font-size:20px;color:#666}
      #ccl-ok{margin-top:8px;padding:16px 64px;border-radius:10px;cursor:pointer;font-size:26px;font-weight:700;background:#2e7d32;color:#fff;border:2px solid #2e7d32}`;
    overlay.appendChild(style);
    document.body.appendChild(overlay);

    const ok = () => overlay.remove();
    overlay.querySelector('#ccl-ok').onclick = ok;
    overlay.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' || e.key === 'Enter') { e.preventDefault(); ok(); }
    });
    overlay.querySelector('#ccl-ok').focus();
  }
})();
