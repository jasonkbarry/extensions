@echo off
title All Nextiva Extensions installer
rem Installs or updates All Nextiva Extensions. Double-click to run.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$x='all'; irm https://jasonkbarry.github.io/extensions/install.txt | iex"
