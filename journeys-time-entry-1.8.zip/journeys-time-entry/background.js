// Journeys Time Entry — background service worker
// Talks to the Journeys API (onboarding.nextiva.com) using your signed-in session.

const BASE = 'https://onboarding.nextiva.com';

// Boards are added by each user in ⚙ settings (paste a board URL).
const DEFAULT_BOARDS = [];

const ADMIN_LABELS = {
  pto_holiday: 'FTO / Holiday',
  internal_meeting: 'Internal meeting',
  admin_email: 'Admin / email',
  training: 'Training',
  internal_project: 'Internal project',
  npi_management: 'NPI management'
};

// ---------- setup ----------
chrome.runtime.onInstalled.addListener(async () => {
  const { boards, sheetTab } = await chrome.storage.local.get(['boards', 'sheetTab']);
  if (!boards) await chrome.storage.local.set({ boards: DEFAULT_BOARDS });
  else {
    // add Burn Down defaults to boards saved by older versions
    let changed = false;
    for (const b of boards) {
      const d = DEFAULT_BOARDS.find(x => x.workspaceId === b.workspaceId);
      if (!b.sheet && d) { b.sheet = d.sheet; changed = true; }
    }
    if (changed) await chrome.storage.local.set({ boards });
  }
  scheduleReminder();
});
chrome.runtime.onStartup.addListener(scheduleReminder);

// ---------- Wednesday reminder (4 PM local, time is due at 7 PM) ----------
function nextWednesday4pm() {
  const now = new Date();
  const t = new Date(now);
  t.setHours(16, 0, 0, 0);
  t.setDate(now.getDate() + ((3 - now.getDay() + 7) % 7));
  if (t <= now) t.setDate(t.getDate() + 7);
  return t.getTime();
}
async function scheduleReminder() {
  const a = await chrome.alarms.get('wedReminder');
  if (!a) chrome.alarms.create('wedReminder', { when: nextWednesday4pm() });
}
chrome.alarms.onAlarm.addListener(a => {
  if (a.name !== 'wedReminder') return;
  chrome.notifications.create('wedReminder', {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'Time entry due at 7 PM',
    message: 'Your Journeys time needs to be entered by 7 PM today.',
    priority: 2
  });
  chrome.alarms.create('wedReminder', { when: nextWednesday4pm() });
});
chrome.notifications.onClicked.addListener(id => {
  if (id === 'wedReminder') chrome.tabs.create({ url: BASE + '/employee/pm/timesheet' });
});

// ---------- API helpers ----------
const ymd = d => {
  const z = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
};
const parse = t => { try { return JSON.parse(t); } catch { return null; } };

async function directFetch(path, opts) {
  const r = await fetch(BASE + path, { credentials: 'include', ...opts });
  const text = await r.text();
  return { ok: r.ok, status: r.status, text, data: parse(text) };
}

function waitForLoad(tabId) {
  return new Promise(resolve => {
    let timer;
    const listener = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const done = () => {
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      setTimeout(resolve, 1500);
    };
    timer = setTimeout(done, 25000);
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// Fallback: run the request inside a Journeys tab so it uses the page's own session.
async function tabFetch(path, opts) {
  let [tab] = await chrome.tabs.query({ url: BASE + '/*' });
  let created = false;
  if (!tab) {
    tab = await chrome.tabs.create({ url: BASE + '/employee/pm/timesheet', active: false });
    created = true;
    await waitForLoad(tab.id);
    tab = await chrome.tabs.get(tab.id);
    if (!tab.url || !tab.url.startsWith(BASE)) {
      await chrome.tabs.update(tab.id, { active: true });
      throw new Error('Sign in to Journeys in the tab that just opened, then try again.');
    }
  }
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: async (p, o) => {
        const r = await fetch(p, { credentials: 'include', ...o });
        return { ok: r.ok, status: r.status, text: await r.text() };
      },
      args: [path, opts || {}]
    });
    const v = res.result;
    return { ...v, data: parse(v.text) };
  } finally {
    if (created) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function api(path, opts = {}) {
  let r = null;
  try { r = await directFetch(path, opts); } catch (e) { r = null; }
  const htmlInsteadOfJson = r && r.ok && r.data === null && r.text.trim().startsWith('<');
  if (!r || r.status === 401 || r.status === 403 || htmlInsteadOfJson) {
    r = await tabFetch(path, opts);
  }
  if (!r.ok) {
    if (r.status === 401 || r.status === 403) {
      throw new Error('Not signed in to Journeys. Open onboarding.nextiva.com, sign in, and try again.');
    }
    const d = r.data || {};
    const msg = d.message || d.error || d.detail || `HTTP ${r.status}`;
    throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
  }
  return r.data;
}

// ---------- operations ----------
async function getActivities(workspaceId) {
  const b = await api(`/api/pm/post-onboarding/${workspaceId}/board?laneLimit=60&today=${ymd(new Date())}`);
  return (b.cards || [])
    .filter(c => !c.isArchived)
    .sort((a, c) => (a.position ?? 0) - (c.position ?? 0))
    .map(c => ({ id: c.id, title: c.title, lane: c.laneCode, done: !!c.isComplete }));
}

async function getPins() {
  const p = await api('/api/pm/me/timesheet-pins');
  return (p.pins || [])
    .filter(x => x.kind === 'non_project' && x.available !== false)
    .map(x => {
      const key = x.title || String(x.rowKey || '').replace('nonproject:', '');
      const label = ADMIN_LABELS[key] || key.replace(/_/g, ' ').replace(/^./, s => s.toUpperCase());
      return { key, label };
    });
}

async function resolveBoard(url) {
  const m = String(url).match(/accounts\/([0-9a-f-]{36})\/projects\/([0-9a-f-]{36})/i);
  if (!m) throw new Error('That doesn\u2019t look like a Journeys board URL (it needs /accounts/\u2026/projects/\u2026).');
  const [, accountId, projectId] = m;
  const p = await api(`/api/pm/projects/${projectId}/post-onboarding`);
  const workspaceId = p && p.workspace && p.workspace.id;
  if (!workspaceId) throw new Error('No post-onboarding board was found for that project.');
  let name = 'Board';
  try {
    const a = await api('/api/pm/accounts');
    const acct = (a.accounts || []).find(x => x.id === accountId);
    if (acct) name = acct.name;
  } catch { /* keep default name */ }
  return { name, accountId, projectId, workspaceId };
}

async function getWeek() {
  const now = new Date();
  const mon = new Date(now);
  mon.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const sun = new Date(mon);
  sun.setDate(mon.getDate() + 6);
  const te = await api(`/api/pm/time-entries?dateFrom=${ymd(mon)}&dateTo=${ymd(sun)}`);
  const entries = te.entries || [];
  const today = ymd(now);
  const sum = arr => arr.reduce((s, e) => s + (Number(e.hours) || 0), 0);
  return {
    week: sum(entries),
    today: sum(entries.filter(e => e.entryDate === today)),
    billable: sum(entries.filter(e => e.billable))
  };
}

async function getWeekEntries(from, to) {
  const te = await api(`/api/pm/time-entries?dateFrom=${from}&dateTo=${to}`);
  return (te.entries || []).map(e => ({
    id: e.id,
    date: e.entryDate,
    hours: Number(e.hours) || 0,
    billable: !!e.billable,
    notes: e.notes || '',
    cardId: e.postOnboardingCardId || null,
    workspaceId: e.postOnboardingWorkspaceId || null,
    category: e.nonProjectCategory || null
  }));
}

// ---------- submission ----------
async function submitOne(item) {
  const headers = { 'Content-Type': 'application/json' };
  if (item.op === 'update') {
    return api(`/api/pm/time-entries/${item.entryId}`, { method: 'PATCH', headers, body: JSON.stringify({ hours: item.hours }) });
  }
  if (item.op === 'delete') {
    return api(`/api/pm/time-entries/${item.entryId}`, { method: 'DELETE' });
  }
  if (item.kind === 'project') {
    return api(`/api/pm/post-onboarding/cards/${item.cardId}/time-entries`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        entryDate: item.date,
        hours: item.hours,
        billingCategory: 'technical',
        billable: !!item.billable,
        notes: item.notes || null
      })
    });
  }
  return api('/api/pm/time-entries', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      category: item.category,
      entryDate: item.date,
      hours: item.hours,
      notes: item.notes || null,
      ticketReference: null
    })
  });
}

// ---------- Burn Down sheet (Apps Script web app) ----------
async function sheetCall(body) {
  const { sheetUrl, sheetId = '', sheetTab = '', sheetToken = '' } = await chrome.storage.local.get(['sheetUrl', 'sheetId', 'sheetTab', 'sheetToken']);
  if (!sheetUrl) throw new Error('Burn Down sheet web app URL is not set (⚙ settings).');
  if (!sheetId) throw new Error('Burn Down sheet link is not set (⚙ settings).');
  if (!sheetTab) throw new Error('Burn Down tab name is not set (⚙ settings).');
  let r;
  try {
    r = await fetch(sheetUrl, {
      method: 'POST',
      credentials: 'include',
      redirect: 'follow',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ sheetId, tab: sheetTab, token: sheetToken, ...body })
    });
  } catch (e) {
    throw new Error('Could not reach the Burn Down web app (' + e.message + ').');
  }
  const text = await r.text();
  const data = parse(text);
  if (!data) {
    if (/accounts\.google\.com|ServiceLogin|<html/i.test(text)) {
      throw new Error('Google sign-in needed for the Burn Down web app. Open the web app URL once in Chrome while signed in to the Google account that owns it.');
    }
    throw new Error(`Burn Down web app returned HTTP ${r.status}.`);
  }
  if (!data.ok) throw new Error('Burn Down sheet: ' + (data.error || 'unknown error'));
  return data;
}

async function sheetAppend(rows) {
  if (!rows.length) return { ok: true, written: [] };
  const { sheetPending = [] } = await chrome.storage.local.get('sheetPending');
  try {
    const data = await sheetCall({ action: 'append', rows });
    return { ok: true, written: data.written || [] };
  } catch (e) {
    await chrome.storage.local.set({ sheetPending: sheetPending.concat(rows) });
    return { ok: false, error: e.message, pending: sheetPending.length + rows.length };
  }
}

async function sheetRetry() {
  const { sheetPending = [] } = await chrome.storage.local.get('sheetPending');
  if (!sheetPending.length) return { ok: true, written: [] };
  const data = await sheetCall({ action: 'append', rows: sheetPending });
  await chrome.storage.local.set({ sheetPending: [] });
  return { ok: true, written: data.written || [] };
}

let submitting = false;
async function submitItems(items) {
  if (submitting) throw new Error('A submit is already in progress.');
  submitting = true;
  const results = {};
  try {
    for (const item of items) {
      try {
        await submitOne(item);
        results[item.id] = { ok: true };
        const { log = [] } = await chrome.storage.local.get('log');
        log.unshift({ ...item, doneAt: Date.now() });
        await chrome.storage.local.set({ log: log.slice(0, 40) });
      } catch (e) {
        results[item.id] = { ok: false, error: e.message || String(e) };
      }
    }
    // Burn Down sheet: one row per billable entry that was just created in Journeys
    const rows = items.filter(it => results[it.id] && results[it.id].ok && it.sheetRow)
      .map(it => ({ ...it.sheetRow, ref: it.id }));
    const sheet = rows.length ? await sheetAppend(rows) : null;
    return { results, sheet };
  } finally {
    submitting = false;
  }
}

// ---------- messaging ----------
async function handle(msg) {
  switch (msg.type) {
    case 'activities': return getActivities(msg.workspaceId);
    case 'pins': return getPins();
    case 'resolveBoard': return resolveBoard(msg.url);
    case 'week': return getWeek();
    case 'weekEntries': return getWeekEntries(msg.from, msg.to);
    case 'submitItems': return submitItems(msg.items || []);
    case 'sheetTest': return sheetCall({ action: 'ping' });
    case 'sheetRetry': return sheetRetry();
    case 'defaultBoards': return DEFAULT_BOARDS;
    default: throw new Error('Unknown request: ' + msg.type);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg).then(
    result => sendResponse({ ok: true, result }),
    err => sendResponse({ ok: false, error: err.message || String(err) })
  );
  return true;
});
